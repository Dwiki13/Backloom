---
name: postgres-pgadmin-troubleshooting
description: "Troubleshoot PostgreSQL connection issues via pgAdmin and fix FastAPI auth duplicate key errors"
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [postgres, pgadmin, fastapi, auth, troubleshooting, database, api]
---

# Postgres pgAdmin Connection Troubleshooting and FastAPI Auth Fix

## Overview
This skill covers two common issues encountered in the VPS environment:
1. pgAdmin unable to connect to PostgreSQL due to host/misconfiguration or password encryption mismatches.
2. FastAPI auth endpoint throwing `UniqueViolation` on `users_email_key` during registration/login.

Both issues were observed and resolved in the session; the fixes are captured here for future reuse.

---

## Part 1: PostgreSQL pgAdmin Connection Issues

### Trigger
- pgAdmin web UI shows "Unable to connect to server" with errors like:
  - `connection refused`
  - `Failed to decrypt the saved password`
  - Repeated 401 Unauthorized attempts in logs.
- Mobile app or external client cannot reach the DB.

### Steps
1. **Verify PostgreSQL container is running**
   ```bash
   docker ps | grep postgres
   ```
   Ensure the container is healthy and port 5432 is exposed.

2. **Check host firewall (ufw)**
   ```bash
   ufw status | grep 5432
   ```
   If missing, allow the port:
   ```bash
   sudo ufw allow 5432/tcp
   ```

3. **Test TCP connectivity from pgAdmin container**
   ```bash
   # Inside pgAdmin container
   docker exec pgadmin sh -c 'nc -zv postgres 5432'
   # or using python
   docker exec pgadmin python3 -c "import socket; s=socket.socket(); s.settimeout(3); print(s.connect_ex(('postgres',5432))==0)"
   ```
   Should return success (`0` or `True`).

4. **Configure pgAdmin server correctly**
   - In pgAdmin web UI, edit server → Connection tab.
   - **Host**: Use the Docker service name (`postgres`), *not* `localhost` or `127.0.0.1`.
   - **Port**: `5432`
   - **Maintenance DB**: `postgres` (or target DB, e.g., `hermesdb`)
   - **Username**: `hermes` (as set in POSTGRES_USER env)
   - **Password**: Enter the password (same as POSTGRES_PASSWORD).
   - ☑️ **Save Password** (critical – lets pgAdmin encrypt it correctly).
   - Save and reconnect.

5. **If you see "Failed to decrypt the saved password"**
   - This means the password stored in pgAdmin's DB was encrypted with an incompatible method (e.g., manual encryption outside pgAdmin).
   - Delete the problematic server record:
     ```bash
     # Find the server ID (from pgAdmin logs or UI)
     docker exec pgadmin /usr/local/bin/python3 -c "
     import sqlite3
     conn = sqlite3.connect('/var/lib/pgadmin/pgadmin4.db')
     c = conn.cursor()
     c.execute('SELECT id, name FROM server WHERE name LIKE \"%Hermes%\"')
     rows = c.fetchall()
     for r in rows:
         print(f'ID:{r[0]} Name:{r[1]}')
     # Delete the offending ID (replace <ID>)
     c.execute('DELETE FROM server WHERE id=<ID>')
     conn.commit()
     conn.close()
     "
     ```
   - Re-register the server via the UI (step 4) to let pgAdmin handle encryption.

6. **Verify connection**
   - Click the connect icon in pgAdmin tree.
   - Run a test query: `SELECT version();`.

### Pitfalls
- **Manual password encryption**: Encrypting the password outside pgAdmin (via Python scripts) leads to decryption mismatches because pgAdmin uses a secret‑key‑derived AES‑CFB8 scheme that is not reproducible without access to its internal key.
- **Host confusion**: From within the pgAdmin container, the host `postgres` resolves to the PostgreSQL container’s internal IP. Using `localhost` or `127.0.0.1` points to the pgAdmin container itself, causing connection refused.
- **Firewall overrides**: Even though Docker exposes the port, the host firewall (ufw) may block external access. Ensure rules allow the port.
- **Saving password**: Forgetting to check "Save Password" forces re‑entry each time and may cause pgAdmin to store a null/empty password blob, leading to auth failures.
- **Multiple server records**: Old or duplicate server entries can cause confusion; remove stale records before adding a new one.

### Verification
- Successful connection in pgAdmin UI.
- Ability to run SQL queries and see results.
- No decryption or authentication errors in pgAdmin logs.

---

## Part 2: FastAPI Auth Duplicate Key Fix

### Trigger
- Registering or logging in via Firebase throws SQLAlchemy `IntegrityError`:
  ```
  sqlalchemy.exc.IntegrityError: (psycopg2.errors.UniqueViolation) duplicate key value violates unique constraint "users_email_key"
  ```
- Happens when a user with an existing email tries to register/login with a different (or empty) `firebase_uid`.

### Root Cause
The auth endpoints checked only for existing `firebase_uid` before inserting a new user. They did not verify whether the email already existed with a different `firebase_uid` (or none), leading to an insert that violates the unique email constraint.

### Fix Applied
Modified `/root/projects/subtrack-id/backend/app/routes/auth.py`:

#### Register endpoint (`/api/v1/auth/register`)
- After extracting `email` from the Firebase token, check if a user with that email already exists.
- If yes, raise `409 Conflict` (user already registered) – do not attempt to insert.
- Only if email is free, proceed to create a new user.

#### Login endpoint (`/api/v1/auth/login`)
- If no user is found by `firebase_uid`, check if a user exists with the same email.
- If such a user exists and lacks a `firebase_uid`, link the current `firebase_uid` to that account (update the record) and return the user.
- If the email user already has a different `firebase_uid`, treat as conflict (or handle per business logic – in this case we still raise 409 to avoid overriding).

### Code Snippet (post‑fix)
```python
# In register
email = decoded.get("email", f"{firebase_uid}@placeholder.subtrack.id")
# Check if email already exists with different firebase_uid
existing_email = db.query(User).filter(User.email == email).first()
if existing_email:
    # Link firebase_uid to existing account if not already set
    if not existing_email.firebase_uid:
        existing_email.firebase_uid = firebase_uid
        db.commit()
        db.refresh(existing_email)
    raise HTTPException(status_code=409, detail="User already registered")

# In login
user = db.query(User).filter(User.firebase_uid == firebase_uid).first()
if not user:
    email = decoded.get("email", f"{firebase_uid}@placeholder.subtrack.id")
    # Check if email already exists (e.g., user signed in with different provider)
    existing_email = db.query(User).filter(User.email == email).first()
    if existing_email:
        # Link this firebase_uid to existing account
        if not existing_email.firebase_uid:
            existing_email.firebase_uid = firebase_uid
            db.commit()
            db.refresh(existing_email)
        user = existing_email
    else:
        # Create new user
        display_name = decoded.get("name") or email.split("@")[0]
        user = User(
            firebase_uid=firebase_uid,
            email=email,
            display_name=display_name,
        )
        db.add(user)
        db.commit()
        db.refresh(user)
```

### Verification
- Registering a new user with a fresh email succeeds.
- Logging in with a known Firebase UID returns the existing user.
- Attempting to register with an email that already exists (regardless of firebase_uid) returns `409 Conflict` instead of a 500 error.
- No `UniqueViolation` errors appear in the API logs.

### References
- See `references/fastapi-auth-duplicate-key-fix.md` for the exact diff and error traceback.

---
**Note**: This skill combines two related troubleshooting guides that appeared in the same session. If you prefer separate skills, you can split them into `postgres-pgadmin-troubleshooting` and `fastapi-auth-duplicate-key-fix`.