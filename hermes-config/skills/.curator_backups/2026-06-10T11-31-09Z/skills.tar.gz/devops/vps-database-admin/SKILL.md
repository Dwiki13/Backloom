---
name: vps-database-admin
description: >
  Manage PostgreSQL databases and pgAdmin via Docker on a VPS. Diagnose connection issues,
  register servers, fix auth failures, and debug Docker networking between containers.
  Trigger when user asks about pgAdmin 401 errors, PostgreSQL connection refused, Docker
  container networking, or database server registration.
---

# VPS Database Admin

## Scope

PostgreSQL + pgAdmin4 running in Docker containers on a VPS. Covers connection debugging, auth repair, server registration, and Docker network diagnostics.

## Common Patterns

### Diagnosing pgAdmin 401 Errors

1. **Check pgAdmin logs**: `docker logs pgadmin --tail 50`
2. **Look for connect_server POST returning 401** — means stored password doesn't match PostgreSQL user password
3. **Verify actual password**: `docker exec postgres psql -U <user> -d <db> -c "SELECT 1"`
4. **Check pgAdmin server table** via SQLite query through pgAdmin's venv Python

## Fixing a Wrong Password in pgAdmin

**⚠️ DO NOT inject encrypted passwords from outside pgAdmin.** Even if you use pgAdmin's own SECRET_KEY and AES-CFB8 algorithm correctly, pgAdmin's running process cannot decrypt externally-encrypted passwords. The decrypt fails with: `UnicodeDecodeError: 'utf-8' codec can't decode byte 0xaf`.

**The only reliable fix:**

1. Delete the broken server entry directly from SQLite:
   ```python
   import sqlite3
   db = sqlite3.connect('/var/lib/pgadmin/pgadmin4.db')
   c = db.cursor()
   c.execute('DELETE FROM server WHERE id=<id>')
   db.commit()
   ```
2. Have the user re-register the server via pgAdmin web UI (`Server → Register → Server`)
3. pgAdmin encrypts and stores the password itself — guaranteed to work
4. Only manual config needed: set host as the Docker container name (e.g. `postgres`) since pgAdmin connects from within the Docker network

**If there are ZERO servers (clean slate):**
- The simplest approach is to let the user register via UI rather than injecting via SQL

### Verifying Docker Network Connectivity

1. **Same network check**: `docker inspect <container> --format '{{json .NetworkSettings.Networks}}'`
2. **DNS resolution**: `docker exec pgadmin sh -c 'getent hosts <service_name>'`
3. **Ping test**: `docker exec pgadmin sh -c 'ping -c 1 <service_name>'`
4. Container names resolve within the same Docker network — no IP needed

## Key Quirks

- pgAdmin metadata DB: `/var/lib/pgadmin/pgadmin4.db`
- SECRET_KEY stored in `keys` table — used as AES encryption key for passwords (but don't try to use it externally, see above)
- `dpage/pgadmin4` is Alpine-based — `apk` not `apt`, may lack root for package install
- pgAdmin runs as user `pgadmin` (UID 5050)
- **pgAdmin connects from inside the Docker network** — use the Docker container name as host (e.g. `postgres`), NOT `localhost` or `127.0.0.1`. Hostname resolution only works within the same Docker network.
- Users access pgAdmin web UI via `http://<vps-ip>:5050` — this is a browser connecting to pgAdmin server inside Docker, NOT pgAdmin desktop connecting to PostgreSQL
- Wait ~10s after `docker restart pgadmin` for it to come back up

## FastAPI / Uvicorn on Host (Not Docker)

### Firebase credentials `FileNotFoundError` kills all routes
If `firebase-credentials.json` path is relative (e.g. `"firebase-credentials.json"`), the process **must** be started with `cwd` set to the project directory. If started from the wrong directory:
- `FileNotFoundError` at module import time
- ALL routes that import `firebase_admin` return 500
- `/health` still works (it doesn't import auth)
- Fix: restart uvicorn with explicit `cwd=/path/to/backend`

### Multiple uvicorn processes
When restarting, old processes may survive. Always:
1. `pkill -f uvicorn` then `sleep 3`
2. Verify with `ps aux | grep uvicorn` — ensure only ONE instance remains
3. Docker containers may auto-restart — check `docker ps` for duplicate services

### Port mapping confusion
- SubTrack API Docker container: port 8002→8000
- Host-spawned uvicorn: port 8000 directly
- Both can run simultaneously causing conflicts
- Prefer Docker container for production; kill host-spawned duplicates

## Pitfalls

### Externally encrypted passwords don't work
Manually encrypting a password with pgAdmin's SECRET_KEY and SQL-inserting it into the `server` table **will fail at connect time** even if local roundtrip test passes. The running pgAdmin process rejects the decrypted bytes. Always register via pgAdmin web UI.

### Session table is empty after restart
If pgAdmin was restarted after a manual SQL insert and the server entries disappeared, it's because `sqlite_sequence` wasn't updated or pgAdmin regenerated its DB. The entry would have shown a "Could not decrypt saved password" error anyway — this is a sign to use UI registration.

### Connection from PC/laptop
pgAdmin web can be accessed from any browser at `http://<vps-ip>:5050`. But if the user wants pgAdmin desktop on their PC connecting directly to PostgreSQL, they need:
- PostgreSQL port (`5432`) open/forwarded on the VPS
- pgAdmin in the Docker container must be on the same Docker network as PostgreSQL host
- The Dockerfile `postgres` container must be reachable at its published port

### hosts file quick-test
When DNS hasn't propagated yet, add `<VPS_IP> your.domain.id` to the hosts file to test from a specific machine immediately:
- **Windows**: `C:\Windows\System32\drivers\etc\hosts` (open as Admin)
- **Linux/Mac**: `/etc/hosts` (`sudo nano /etc/hosts`)
- Only works on that one machine. Remove when DNS is live.

## References

- [pgadmin-server-injection.md](references/pgadmin-server-injection.md) — Full script for injecting a server entry with proper encryption
- [firebase-auth-email-collision.md](references/firebase-auth-email-collision.md) — Fixing `users_email_key` UniqueViolation in Firebase auth register/login
- [npm-proxy-host-config.md](references/npm-proxy-host-config.md) — NPM proxy host config: correct directory, SSL pitfalls, debugging flow
- [npm-docker-domain-diagnosis.md](references/npm-docker-domain-diagnosis.md) — Full diagnostic sequence: DNS → NPM config → Docker network → container health → SSL → end-to-end test

## NPM Reverse Proxy Setup

### Correct Config Directory
NPM proxy host configs go in `/data/nginx/proxy_host/` (**underscore**). The nginx include is:
```
include /data/nginx/proxy_host/*.conf;
```
Files placed in `/data/nginx/proxy-hosts/` (hyphen) are **silently ignored**.

### SSL Certificate Directive Pitfall
When creating a proxy host config, ensure `ssl_certificate` appears exactly ONCE and `ssl_certificate_key` is present. A duplicate `ssl_certificate` line causes `nginx: [emerg] conflicting ssl_certificate`. A missing `ssl_certificate_key` causes `nginx: [emerg] no "ssl_certificate_key" is defined`.

### Verifying a Proxy Host Config
```bash
docker exec npm_npm_1 nginx -t                              # syntax check
docker exec npm_npm_1 nginx -T | grep "server_name domain"  # block loaded?
docker exec npm_npm_1 sh -c "nginx -s reload"               # apply changes
```

## FastAPI / Uvicorn: Firebase Credentials cwd Pitfall

If `FIREBASE_CREDENTIALS_PATH` is a relative path (e.g., `"firebase-credentials.json"`), uvicorn **must** be started with `cwd` set to the project backend directory. If started from the wrong directory:
- `FileNotFoundError` at module import time (module-level `credentials.Certificate()` call)
- ALL routes that import `firebase_admin` return 500
- `/health` still works (doesn't import auth)
- Fix: restart uvicorn with explicit `cwd=/path/to/backend`

## Multiple Uvicorn Processes

When restarting, old processes may survive and cause port conflicts:
1. `pkill -f uvicorn` then `sleep 3`
2. Verify with `ps aux | grep uvicorn` — ensure only ONE instance of `app.main:app` remains
3. Docker containers auto-restart — `docker ps` may show both container and host-spawned processes
4. Kill host-spawned duplicates; prefer Docker container for production

## Port Mapping Reference

| Service | Container | Container Port | Host Mapped Port |
|---------|-----------|----------------|------------------|
| SubTrack API | subtrack-api | 8000 | 8002 |
| Second Brain | secondbrain-api | 8000 | 8001 |
| pgAdmin | pgadmin | 80 | 5050 |
| NPM | npm_npm_1 | 80, 81, 443 | 80, 81, 443 |
| PostgreSQL | postgres | 5432 | 5432 |
