# SubTrack ID — Project Reference

## Project Info
- Repo: https://github.com/Dwiki13/subtrack-id
- Stack: FastAPI backend + Flutter mobile
- Domain: Subscription tracker for Indonesian market

## Constraint: Mobile Code is IMMUTABLE
- KII's Flutter mobile app has been pushed and must NOT be modified by agents
- All "Connect Flutter app" tasks = backend-side work only
- Never edit files under /root/projects/subtrack-id/mobile/ without explicit KII approval

## Deployment
- VPS: 202.10.46.161
- Docker Compose v1 (hyphen syntax)
- Deploy key: ~/.ssh/subtrack_deploy
- Backend port: 8002 (docker-compose.prod.yml)

## Backend API Endpoints (Complete List)

### Auth (`/api/v1/auth`)
| Method | Path | Mobile Integrated | Description |
|--------|------|-------------------|-------------|
| POST | `/login` | ✅ | Firebase Bearer token → auto-register if new |
| POST | `/register` | ✅ | Firebase Bearer token → register |
| GET | `/me` | ✅ | Get current user profile |

### Subscriptions (`/api/v1/subscriptions`)
| Method | Path | Mobile Integrated | Description |
|--------|------|-------------------|-------------|
| GET | `/` | ✅ | List user subscriptions (limit, offset) |
| POST | `/` | ✅ | Create subscription |
| GET | `/:id` | ❌ | Get single subscription detail |
| PUT | `/:id` | ✅ | Update subscription |
| DELETE | `/:id` | ✅ | Soft-delete (is_active=false) |
| GET | `/stats/summary` | ✅ | Monthly/yearly totals, upcoming, trials |

### Family (`/api/v1/family`)
| Method | Path | Mobile Integrated | Description |
|--------|------|-------------------|-------------|
| POST | `/` | ✅ | Create family vault |
| POST | `/join/:code` | ✅ | Join vault via invite code |
| GET | `/my-vaults` | ❌ | List vaults user belongs to |
| GET | `/:id/members` | ❌ | List vault members |

### Payments (`/api/v1/payments`)
| Method | Path | Mobile Integrated | Description |
|--------|------|-------------------|-------------|
| POST | `/create` | ✅ | Create payment record (plan: pro/family, period: monthly/yearly) |
| GET | `/history` | ❌ | Payment history for current user |
| POST | `/webhook/midtrans` | N/A | Midtrans notification webhook (backend-only) |

### Detector (`/api/v1/detect`)
| Method | Path | Mobile Integrated | Description |
|--------|------|-------------------|-------------|
| POST | `/` | ❌ | Upload PDF/image → OCR → detect subscriptions |

### Notifications (`/api/v1/notifications`)
| Method | Path | Mobile Integrated | Description |
|--------|------|-------------------|-------------|
| POST | `/register-token` | ❌ | Register FCM token |
| POST | `/send-test` | ❌ | Send test push notification |
| GET | `/settings` | ❌ | Get notification settings |
| PUT | `/settings` | ❌ | Update notification settings |

### Admin Scheduler (`/api/v1/admin/scheduler`)
| Method | Path | Mobile Integrated | Description |
|--------|------|-------------------|-------------|
| POST | `/trigger-billing-check` | N/A | Admin only |
| POST | `/trigger-trial-check` | N/A | Admin only |
| GET | `/status` | N/A | Admin only |

## Mobile Integration Status (as of 2026-06-08)

### ✅ Already in `api_service.dart`:
- `login()`, `register()`, `getMe()`
- `getSubscriptions()`, `createSubscription()`, `updateSubscription()`, `deleteSubscription()`
- `getStats()`
- `createFamilyVault()`, `joinFamilyVault()`
- `createPayment()`

### ❌ NOT yet in `api_service.dart` (need to add):
- `getSubscription(id)` — GET `/api/v1/subscriptions/:id`
- `getMyVaults()` — GET `/api/v1/family/my-vaults`
- `getVaultMembers(id)` — GET `/api/v1/family/:id/members`
- `getPaymentHistory()` — GET `/api/v1/payments/history`
- `uploadDetection(file)` — POST `/api/v1/detect` (multipart upload)
- `registerFcmToken(token)` — POST `/api/v1/notifications/register-token`
- `sendTestNotification()` — POST `/api/v1/notifications/send-test`
- `getNotificationSettings()` — GET `/api/v1/notifications/settings`
- `updateNotificationSettings(enabled)` — PUT `/api/v1/notifications/settings`

## OCR Detector Implementation (2026-06-08)
- PDF: `pdfplumber` → extract text per page from `BytesIO(content)`
- Image: `PIL.Image.open(BytesIO(content))` → `pytesseract.image_to_string()`
- Detection: `detect_from_text(text)` from `services/detector.py` (keyword + price matching)
- Env verified: tesseract 5.3.4, pdfplumber, pytesseract, Pillow all OK
- Test: 6/6 subscriptions detected from sample OCR text

## Backend TODOs (as of 2026-06-08)
1. ✅ OCR Detector — implemented and pushed (2026-06-08)
2. ❌ Midtrans Snap integration — `create` route needs to call `create_midtrans_transaction()` and return Snap URL
3. ❌ Set `external_transaction_id` on payment record before saving
4. ❌ Alembic migrations setup
5. ❌ API/route integration tests

## ⚠️ CRITICAL PITFALL: SQLAlchemy Enum Value Mismatch

**Symptom:** HTTP 500 on any endpoint that loads a User from DB (e.g. `GET /api/v1/auth/me`).
**Root cause:** Enum values in Python code are lowercase (`"free"`, `"pro"`, `"family"`), but DB may contain uppercase (`"FAMILY"`).
SQLAlchemy/SQLEnum does NOT auto-convert case. If DB value doesn't match the enum value exactly, loading the ORM object throws.

**How it happens:**
- KII manually updates tier in DB: `UPDATE users SET tier = 'FAMILY' WHERE ...`
- Python `UserTier` enum has `FAMILY = "family"` (lowercase)
- SQLAlchemy tries to construct `UserTier("FAMILY")` → fails because `"FAMILY" ∉ {"free", "pro", "family"}`

**Fix:** Always use lowercase when manually updating enum columns:
```sql
-- ✅ Correct
UPDATE users SET tier = 'family' WHERE email = '...';
-- ❌ Wrong
UPDATE users SET tier = 'FAMILY' WHERE email = '...';
```

**General rule:** For any `str, enum.Enum` + `SQLEnum` column, the stored DB value is whatever the `.value` is — always lowercase if the enum member value is lowercase. This applies to `UserTier`, `BillingCycle`, `Category`, `PaymentStatus`, `PaymentMethod`.

## ⚠️ CRITICAL PITFALL: Firebase Auth Token vs FCM Token

Two completely different tokens in Firebase — never confuse them:

| | Firebase Auth Token (ID Token) | FCM Registration Token |
|---|---|---|
| **Source** | `FirebaseAuth.instance.currentUser.getIdToken()` | `FirebaseMessaging.instance.getToken()` |
| **Format** | JWT (3 segments, dots) | Long random string |
| **Expires** | 1 hour (auto-refresh) | Long-lived, can change |
| **Auth header** | `Authorization: Bearer <token>` | Not used in headers |
| **Backend verify** | `verify_firebase_token()` in `auth.py` | Stored via `POST /notifications/register-token` |
| **Used for** | Authenticate API requests | Send push notifications |

**Common mistake:** Passing FCM token as Bearer, or vice versa. Backend will return 401 for wrong token type.
