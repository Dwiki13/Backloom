---
name: cronjob-telegram-delivery
description: How to correctly configure Hermes cron jobs that send output to Telegram topics/channels. Covers delivery modes, target format pitfalls, and the local+send_message pattern for topic delivery.
---

# Cron Job → Telegram Delivery

## The Core Rule

**Never use raw numeric chat IDs for Telegram topic delivery.** The format `telegram:<chat_id>:<thread_id>` resolves to a DM, NOT a topic.

## Correct Target Format

For `send_message` tool, use the **group chat ID with topic**:

```
telegram:-1003966561389:334      # ✅ Group MyAssistant24/7, Topic Trading (334)
```

NOT these (they go to DM or fail):
```
telegram:1724161158:334          # ❌ DM (KII's personal chat ID), not topic
telegram:#MyAssistant24/7         # ❌ unresolvable
```

The display name format (`telegram:MyAssistant24/7 / topic 334`) may also work, but the **confirmed working** format as of 2026-06-02 is the numeric group chat ID: `telegram:-1003966561389:334`.

**How to find the group chat ID**: Check the bot's own log — `xauusd_multi_session.py` logs `Telegram OK | chat=<id>`. That `<id>` is the correct group chat ID. Or run `send_message(action='list')` and look for the group entry.

## Pattern: Send to Specific Topic

To send cron output to a specific Telegram topic:

1. Set `deliver: "local"` in the cron job (saves output, doesn't auto-deliver)
2. In the cron prompt, explicitly call `send_message` with the correct target:

```
send_message(target="telegram:MyAssistant24/7 / topic 334", message="<output>")
```

## How to Find the Correct Target

Always run `send_message(action='list')` first to discover available targets. Use the exact string shown (e.g. `telegram:MyAssistant24/7 / topic 334`).

## Pattern: Simple Delivery (No Topic)

If sending to the home channel (no specific topic), you can use:
- `deliver: "origin"` — auto-delivers to the current conversation
- `deliver: "telegram"` — sends to the Telegram home channel

## Reference Setups

- `references/xauusd-bot-setup.md` — XAUUSD Signal Bot: strategies, schedule, broker config, balance updates, market structure, loss review, file layout

## Confirmed Working Pattern (June 2 2026)

The XAUUSD bot (`xauusd_multi_session.py`) uses `send_tg()` internally with `message_thread_id` parsing. The cron job uses `deliver: "local"` and a minimal prompt. This pattern works reliably:

```yaml
schedule: "0 15,16,17,18,19,20,21,22,23 * * *"
deliver: "local"
prompt: |
  Run: python3 /root/projects/trading/xauusd-bot/xauusd_multi_session.py
  Return the stdout output only.
```

Source code lives in `/root/projects/trading/xauusd-bot/` — do NOT copy files to `/root/xauusd-bot/`. Update the prompt path to match wherever KII puts the source.

The bot handles its own Telegram delivery. The cron agent should NOT call `send_message`.

## Common Pitfalls

1. **Numeric chat ID ≠ topic**: `telegram:<chat_id>:<thread_id>` goes to DM, not topic. Always use display name format.
2. **"Send here" ambiguity**: When user says "send here" or "send to this topic", always:
   - Run `send_message(action='list')` to discover targets
   - Send a test message to the candidate target
   - **Ask user to confirm** the test landed in the right place before finalizing cron config
3. **`deliver` to topic doesn't auto-send agent output**: Even with `deliver: "telegram:GroupName / topic N"`, the cron agent output may not auto-route to the topic. Use `deliver: "local"` + explicit `send_message` in the prompt for reliability.
4. **Cron schedule vs strategy hours**: Align cron schedule with the strategy's active hours. Running when all strategies return `None` wastes runs and clutters the channel with "no signal" messages. Check each strategy's time window in the code before setting schedule.
5. **Python bots must explicitly load `.env`**: `os.environ.get("TELEGRAM_BOT_TOKEN", "")` does NOT auto-read `.env` files. If the bot reads config from `.env`, add explicit loading code:
   ```python
   _env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
   if os.path.exists(_env_path):
       with open(_env_path) as _f:
           for _line in _f:
               _line = _line.strip()
               if _line and not _line.startswith("#") and "=" in _line:
                   _k, _v = _line.split("=", 1)
                   _k, _v = _k.strip(), _v.strip().strip('"')
                   if _k == "TELEGRAM_BOT_TOKEN" and not os.environ.get("TELEGRAM_BOT_TOKEN"):
                       os.environ["TELEGRAM_BOT_TOKEN"] = _v
                   elif _k == "TELEGRAM_CHAT_ID" and not os.environ.get("TELEGRAM_CHAT_ID"):
                       os.environ["TELEGRAM_CHAT_ID"] = _v
   ```
   Or use `python-dotenv` if available: `from dotenv import load_dotenv; load_dotenv()`.
6. **Bot self-send vs cron delivery**: If the bot itself sends to Telegram via Bot API (`send_tg()`), set `deliver: "local"` on the cron job to avoid double-delivery. The bot handles its own Telegram delivery; cron just needs to run the script. The cron prompt should be minimal — just run the script and return output. Do NOT add `send_message` in the prompt if the bot already self-sends.
7. **Manual `cronjob run` causes duplicate signals**: Running `cronjob(action="run")` manually while the cron is already scheduled will execute the bot again, generating duplicate signals and journal entries. Never manually trigger a cron job that runs a signal bot — let the schedule handle it. If you need to test, run the Python script directly (`python3 /path/to/bot.py`) and do NOT also call `cronjob run`.
8. **`TELEGRAM_CHAT_ID` with `:thread_id` suffix**: If you set `TELEGRAM_CHAT_ID="-1003966561389:334"` in `.env`, the `send_tg()` function MUST parse it into separate `chat_id` and `message_thread_id` parameters. Passing the colon-separated string as `chat_id` to Telegram API sends to the group's General topic, NOT the intended topic. See code pattern below:
   ```python
   # Chat ID with embedded thread_id: split for Telegram API
   # "chat_id:thread_id" does NOT work — must use separate params
   chat_id = TELEGRAM_CHAT_ID
   params = {"chat_id": chat_id, "text": msg}
   if ":" in str(chat_id):
       parts = str(chat_id).split(":", 1)
       params["chat_id"] = parts[0]
       params["message_thread_id"] = parts[1]
   r = requests.post(url, json=params, timeout=15)
   ```
9. **Balance updates are config-only, not journal entries**: When the user reports a balance change from manual trading, update only the `balance_cent` value in the bot config (`C` dict). Do NOT create journal entries for manual trades — the journal is for bot-generated signals only.
14. **Journal PnL vs real balance diverge**: The journal tracks signal PnL only. User's real balance includes manual trades outside the journal. When user reports total profit (e.g., "signal profit was +352c, rest is manual loss"), adjust journal entries to match signal-level PnL, not the full per-position theoretical calculation. Always ask for per-signal breakdown when totals don't match.
15. **User may report results for signals by chat message number, not journal ID**: When user replies "L for signal #N" to a Telegram message, the #N refers to the signal number in that message, not necessarily the journal ID. Cross-reference by time, strategy, and direction to find the correct journal entry.
16. **Clean up journal after accidental manual cron runs**: If `cronjob(action="run")` was triggered manually and created duplicate entries: (a) identify duplicates by timestamp proximity and same entry price, (b) remove extras, (c) re-number IDs sequentially, (d) recalculate stats, (e) re-anchor `start_balance_cent` to known current balance.
17. **Journal summary Balance must match signal header Balance**: The `fmt_journal_summary()` function must read balance from `C["balance_cent"]` (the config dict), NOT from `j["start_balance_cent"] + st["pnl_cent"]`. The journal's internal `start_balance_cent + pnl_cent` only tracks signal PnL and will always diverge from the real balance when the user trades manually. Always set `bal = C["balance_cent"]` in `fmt_journal_summary()` so the journal footer matches the signal header balance.

18. **WR shown in signal header only, not journal summary**: To avoid redundancy, WR% is shown in the signal header line (`Confidence: 🔥 HIGH | WR: 43% | ⏰ ...`) and NOT repeated in the journal footer. The journal footer shows `W:n L:n BE:n` counts from which WR can be derived.

19. **`DATA_DIR` must be dynamic, never hardcoded**: The bot's `DATA_DIR` must use `os.path.dirname(os.path.abspath(__file__))` so journal, log, and signal files live in the same folder as the source code. Hardcoding `DATA_DIR = "/root/xauusd-bot"` while source is in `/root/projects/trading/xauusd-bot/` causes the bot to read a stale/empty journal, resulting in wrong signal IDs (e.g., #2 instead of #13) and WR showing "N/A" because the new journal has no closed trades. Always verify `DATA_DIR` points to the actual source folder.

20. **When user moves files, update paths — don't copy back**: If the user relocates source files to a new directory, update all references (cron prompts, documentation, config) to point to the new location. Do NOT copy files back to the old location — that creates divergence and data loss. Ask where the files went, then update paths accordingly.
21. **Market structure is dynamic, not static**: The bot recalculates market structure on every run from the latest 20 candles. Trend direction can change between runs. Do not assume the trend from a previous signal still holds — always check the current structure.
22. **Loss review requires closed trades**: `get_loss_review()` only triggers when there are closed losses in the journal. New journals or journals with all OPEN trades will show no loss review. This is expected behavior, not a bug.
23. **Telegram target for group topic — confirmed format**: `telegram:-1003966561389:334` (group numeric ID) is the confirmed working format for KII's Topic Trading. `telegram:1724161158:334` goes to KII's DM, NOT the topic. Always verify with a test message before relying on a new target.
24. **send_message `message_thread_id` via Hermes**: When using `send_message` tool directly (not via bot API), pass `target="telegram:-1003966561389:334"` — Hermes handles the thread routing internally. Do NOT manually split chat_id/thread_id when using `send_message`.
25. **Bot .env file location**: The `.env` file MUST be in the same folder as the script (e.g., `/root/projects/trading/xauusd-bot/.env`). The bot loads it with `os.path.dirname(os.path.abspath(__file__))`. If .env is elsewhere, the bot will use fallback hardcoded values or fail silently.
26. **`TELEGRAM_CHAT_ID` hardcoded fallback in bot script**: The bot script (`xauusd_multi_session.py`) has `TELEGRAM_CHAT_ID = "-1003966561389:334"` as a hardcoded fallback when `.env` is missing. If the `.env` file is deleted or moved, the bot silently uses this fallback — messages go to the right place but `.env` edits won't take effect. Always check both `.env` AND the hardcoded fallback when debugging Telegram delivery issues.
