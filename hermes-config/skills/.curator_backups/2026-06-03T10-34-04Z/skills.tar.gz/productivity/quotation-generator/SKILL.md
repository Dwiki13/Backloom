---
name: quotation-generator
description: "Generate formal business quotations as XLSX/PDF and save to Google Drive. Use when KII asks to create/generate/input a quotation, especially for piping fittings, MRO supplies, or marine/oil&gas equipment. Trigger phrases: 'bikin quotation', 'buat quot', 'generate quotation', 'input quotation', 'quotation untuk PT', 'bikin penawaran'."
version: 2.0.0
---

# Quotation Generator

Generate formal quotations following PT. HARMONI ARTHA SENTRA's template and save to the correct Google Drive Project 2026 folder.

This skill also covers **Delivery Order** and **Invoice** generation — the full document pipeline (QTN → PO → DO → INV) for each client/project. See `references/delivery-order-template.md` and `references/invoice-template.md`.

## Company Info

- **Company:** PT. HARMONI ARTHA SENTRA
- **Tagline:** General Supplier Marine, Oil & Gas, Sparepart, Safety First
- **Address:** Jl. Sabilillah, Kel. Medansatria, Kec. Medansatria, Kota Bekasi, Jabar 17132
- **Phone:** 0877-9178-6187 / 0896-0247-3532
- **Bank Mandiri:** 006-00-5399988-8 a/n PT HARMONI ARTHA SENTRA
- **Bank BCA:** 7410740286 a/n TIAS JULIANSYAH (for Proforma Invoice)

## Document Numbering (Global, NOT per PT)

All document counters are **global across all PTs**. When generating the next document, ALWAYS scan existing files across ALL PT folders to find the highest number, then increment. Stored in `/root/.hermes/data/document-tracker.json`.

| Doc Type | Format | Example |
|----------|--------|---------|
| QTN | QTN/HAS/YYYY/MM/XXX | QTN/HAS/2026/05/011 |
| DO | DO/HAS/YYYY/MM/XXX | DO/HAS/2026/05/004 |
| INV | INV/HAS/YYYY/MM/XXX | INV/HAS/2026/05/001 |
| PI | (same as QTN ref) | Uses referenced QTN number |

Counters auto-increment month if the current month changes.

## Workflow

### 1. Gather Info

Before generating, collect these from the user (ask if not provided):
- **Target client** (which PT from Project 2026 folder)
- **Client contact person** ("Up. [name]")
- **Item list** with: description, quantity, unit of measure, unit price
- **Date** (default: today)
- **Validity** (default: "1 Week")
- **Delivery time** (default: "7-14 Hari")
- **Discount %** (default: 0)
- **Tax %** (default: 11% PPN)
- **References:** PO number, DO number, previous QTN number (for DO/INV generation)

### 2. Generate via Script

**⚠️ Primary: Use the Go version** (`/root/.hermes/docgen/` — see `document-generation` skill). Create a YAML config, run with `go run . --config config.yaml`. The Go version auto-downloads templates from GDrive, converts PDF, uploads, updates tracker, and sends Telegram notification.

**Legacy fallback:** Python script at `/root/.hermes/scripts/document_generator.py`:

```bash
python3 /root/.hermes/scripts/document_generator.py
```

Or call from Python:
```python
import sys; sys.path.insert(0, '/root/.hermes/scripts')
from document_generator import generate_quotation, generate_delivery_order, generate_invoice

### 3. Save to Google Drive

- Folder structure: `Project 2026 > [PT Name] > Quotation/Delivery Order/Invoice`
- File naming: `[PT Name]_QTN_HAS_YYYY_MM_XXX.xlsx` (slashes → underscores locally)
- Upload using Service Account credentials
- Returns `webViewLink` for both Excel and PDF

### 4. Send to User

- Send the Drive webViewLink for both Excel and PDF
- Include summary: doc number, sub total, grand total

## Templates

All templates are stored in `/root/.hermes/templates/`:
- **Quotation HAS.xlsx** — main quotation template
- **Delivery Order HAS.xlsx** — DO template (see `references/delivery-order-template.md`)
- **Invoice HAS.xlsx** — invoice template (see `references/invoice-template.md`)
- **Proforma Invoice.xlsx** — proforma invoice (uses BCA bank, different format)
- **Tertuju Untuk (Template Amplop Invoice).pdf** — envelope template
- **Surat Pernyataan.pdf** — statement letter
- **Kop Surat.pdf** — letterhead

## Folder IDs (Project 2026)

See `references/gdrive-folders.md` for the full, updatable list.

Key IDs:
- Project 2026 root: `12SsvGGk-m6wDPlELcgEtByUsXrWGDYen`
- Each PT folder contains: Quotation, PO, Invoice, Delivery Order subfolders
- Subfolder IDs are auto-created if missing (the script handles this)

Service Account email: `hermes-drive-access@ai-agent-497609.iam.gserviceaccount.com`

## Credentials

- Service Account: `/root/.hermes/credentials/gdrive-service-account.json`
- Scopes: `https://www.googleapis.com/auth/drive`
- Tracker: `/root/.hermes/data/document-tracker.json`

### 2. Generate the XLSX

Use the template structure from `references/quotation-template.md`. Generate via Python/openpyxl:
- Header block (rows 1-13): company info
- Title row: "QUOTATION" centered bold
- Metadata: QTN number, date, Kepada Yth, Up. [contact person]
- Table header (bold bordered): No | Description | Qty | UoM | Harga Unit Price (Rp) | Total
- Data rows with calculated Total = Qty × Unit Price
- Footer section: Sub Total, [optional Discount], PPN 11%, Grand Total
- Notes: Validity, Delivery Time
- T&C section
- Sign-off: "Hormat Kami," + company name

Style:
- Font: Calibri or Arial, 11pt for body, 12pt bold for headers
- Column widths: B(5), C(60), G(8), H(6), I(22), J(20), M(22), O(20), P(8)
- Number format for prices: #,##0
- Borders on table cells
- Subtotal/Grand Total rows bold

### 3. Save to Google Drive

- Folder structure: `Project 2026 > [PT Name] > Quotation`
- File naming convention: `[PT Name]_QTN.HAS.YYYY.MM.XXX.xlsx`
  - Existing uses both `.` and `/` separators — follow what's used in the folder
  - Example: `PT Pelayaran Jangkar Bahurekso Beribadat_QTN_HAS_2026_05_007.xlsx`
- Upload using Service Account credentials at `/root/.hermes/credentials/gdrive-service-account.json`
- See `references/gdrive-upload.md` for the upload code pattern

### 4. Send to User

- Send the Drive link (webViewLink) so the user can review
- If user requests PDF conversion, convert and upload both formats

## Folder IDs (Project 2026)

Stored in memory. Key folder IDs:
- Project 2026 root: `12SsvGGk-m6wDPlELcgEtByUsXrWGDYen`
- Check current folder IDs by listing the root folder contents (IDs may need refreshing)
- Each PT folder contains: Quotation, PO, Invoice, Delivery Order subfolders

## Credentials

- Service Account: `/root/.hermes/credentials/gdrive-service-account.json`
- Scopes: `https://www.googleapis.com/auth/drive`

## Code Pattern

```python
from google.oauth2 import service_account
from googleapiclient.discovery import build

creds = service_account.Credentials.from_service_account_file(
    '/root/.hermes/credentials/gdrive-service-account.json',
    scopes=['https://www.googleapis.com/auth/drive']
)
service = build('drive', 'v3', credentials=creds)

# Upload
file_metadata = {
    'name': filename,
    'parents': [quotation_folder_id]
}
media = MediaFileUpload(local_path, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
file = service.files().create(body=file_metadata, media_body=media, fields='id, webViewLink').execute()
```

## Pitfalls

- **⚠️ Use Go version, not Python, for new work.** The Go version (`/root/.hermes/docgen/`) is the maintained tool. Python script is legacy fallback only.
- **Merged cells in template:** The Excel templates have extensive merged cells. The document generator script handles unmerging before writing. If editing manually, always unmerge → write → re-merge.
- **PDF conversion:** Use `libreoffice --headless --convert-to pdf:calc_pdf_Export [file] --outdir [dir]`. The `--incalc` flag is NOT a valid option and will cause errors.
- **Don't generate without confirmation:** Always show the draft to user first before saving to Drive unless they explicitly say "langsung save" or "langsung upload"
- **Document numbers are GLOBAL** — scan ALL PT folders highest number, not per-PT. Tracker file stores the state.
- **PT folder names** must include exact company name from Drive — always verify before uploading
- **Prices:** When user provides price references from Tokopedia/Shopee, note that prices may have changed — suggest user confirm with seller before finalizing
- **Slash in filename:** `/` is valid in Drive filenames but NOT in local filesystem paths. Replace with `_` when saving locally.
- **Google Drive API errors:** If folder not found, the folder may have been moved. Re-list the root folder to get fresh IDs.
- **LibreOffice PDF conversion timeouts:** Large files or many tables may take >60s. Set timeout=120 minimum.
- **openpyxl merged cell writes:** Writing to a `MergedCell` raises `AttributeError: 'MergedCell' object attribute 'value' is read-only`. **DO NOT unmerge to fix this** — unmerging corrupts the template layout permanently. Instead, write to the top-left cell of the merged range. If the error persists, the template file is corrupted and must be replaced with a clean original. Never use a filled quotation downloaded from Drive as a template.
- **Template column mapping:** Verify the exact cell coordinates for each data field (No, Description, Qty, UoM, Unit Price, Total, Sub Total, Grand Total, Notes, T&C) against the blank template before generating. Wrong column offsets cause data to appear in wrong columns (e.g., writing to L instead of G shifts everything 5 columns right).
- **Bank accounts differ by document type:** Quotation/Invoice use Mandiri (PT HAS), Proforma Invoice uses BCA (Tias Juliansyah). Match the template to the correct bank.

## References

- `references/quotation-template.md` — detailed quotation template structure
- `references/delivery-order-template.md` — DO template structure
- `references/invoice-template.md` — Invoice template structure
- `references/gdrive-upload.md` — Drive upload code patterns
- `references/gdrive-folders.md` — Full folder ID reference
- `references/price-ref-pipe-fittings-2026.md` — pipe fitting price references from Tokopedia (May 2026)

## Scripts

- `scripts/document_generator.py` — Main document generation script (QTN, DO, INV). Load path: `/root/.hermes/scripts/document_generator.py`
