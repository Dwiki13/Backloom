---
name: daily-worklist
description: Daily to-do / worklist tracking for KII — auto-generate today's date, carry over pending tasks, mark stale items. Trigger when user says "todays task", "tambahin todo", "todo hari ini", "update progress", "done", or any task/note tracking request.
---

# Daily Worklist (KII)

Daily task tracking with automatic date generation, pending task carry-over, and stale tagging.

## Rules

1. **ALWAYS auto-generate today's date** — never hardcode or guess dates. Run `TZ='Asia/Jakarta' date +%Y-%m-%d` to get the current date. This is non-negotiable.
2. **One file per day** — `/root/todo-YYYY-MM-DD.md` (e.g. `todo-2026-05-28.md`)
3. **Carry-over on new day** — when user sends tasks for a new day:
   - **WAJIB: Read ALL previous todo files** (at least 3-4 days back) before writing anything. Check each file for tasks marked `[x]` done — those must NEVER reappear in today's list.
   - Read the previous day's file (`/root/todo-YYYY-MM-DD.md`) for carry-over candidates
   - All pending (`- [ ]`) tasks carry over to today's file
   - Done (`- [x]`) tasks stay in the old file as history — do NOT re-add them
   - New tasks appended at the bottom
   - **PITFALL: Never write today's todo without cross-checking history first.** If a task was already done in any previous file, it does not get carried over.
4. **Stale tagging** — when carrying over to a new day, if a task was already pending in the previous day's file AND in the 2-days-ago file, mark it with `⚠️` in the Pending Details table as stale
5. **Task updates via chat** — user can say "nomor X done" or "done #3" to mark complete; check it off in the file
6. **Pending Details table** — maintain a table showing each pending task with Origin (Day N / New) and Stale status (No / Yes)
7. **Cron reminders** — KII uses cron jobs with `no_agent=True` + scripts that send directly via Telegram Bot API curl calls

## File Template

```markdown
# To-Do List — YYYY-MM-DD (Day)

## Tasks

- [ ] 1. Task name
- [x] 2. Task done

## Status

- Done: #2
- Pending: #1

## Pending Details

| # | Task | Origin | Stale |
|---|------|--------|-------|
| 1 | Task name | New / Day N | No / Yes |

## Notes

- Created: YYYY-MM-DD
- Updated: YYYY-MM-DD (description)
```

## Update Pattern

When updating (marking done, adding, removing):

1. Read today's file
2. Apply the change
3. Update Status counts
4. Update Pending Details table
5. Update the "Updated" line in Notes

## Critical Pitfall: No Done-Task Duplication Across Days

**NEVER carry over a task that is already marked `[x]` done in ANY previous file.** Before writing today's todo, scan all recent files (3-5 days back) with `grep -l "TASK_NAME" /root/todo-*.md` or read each file individually. If a task appears as `[x]` in any past file, it is COMPLETE and must not reappear. Only `[ ]` (pending) and `[~]` (in-progress) tasks get carried over.

## 🔴 CRITICAL: Always Carry Over + Show Full Summary on New Day

**When KII sends a task on a new day, the agent MUST:**

1. **Read the previous day's todo file** (`/root/todo-YESTERDAY.md`) BEFORE writing anything
2. **Extract all non-done tasks** (`[ ]` pending + `[~]` in-progress) — these are carry-over
3. **Create today's file** with carry-over tasks FIRST, then new tasks appended
4. **Send a summary showing ALL tasks** — carry-over AND new — in one combined view
5. **NEVER create a fresh todo with only the new task** — leaving out carry-over pending tasks is a bug

**Example flow when KII says "Todo hari ini: UAT Amman":**
```
Step 1: Read /root/todo-2026-06-01.md
Step 2: Find pending/in-progress: "Buat ~/projects [~]", "Buat project playbook [~]", "Aktifkan SQLite FTS [ ]", "RAG/vector search [ ]"
Step 3: Write /root/todo-2026-06-02.md with those 4 carry-over + "UAT Amman" as new task
Step 4: Reply with summary showing ALL 5 tasks (4 carry-over + 1 new)
```

**If carry-over is missed**, KII will call it out. When that happens:
- Acknowledge the mistake
- Read the previous day's file immediately
- Rebuild today's file with the correct carry-over
- Re-send the complete summary

## Pitfall: Stale/Future Todo Files

Sometimes todo files exist for dates that haven't happened yet (e.g., `todo-2026-06-04.md` created during a session on May 31). When reading/writing, ALWAYS use `TZ='Asia/Jakarta' date +%Y-%m-%d` to get the REAL today's date. Never assume from conversation context or system prompt timestamp.

**When carrying over pending tasks to a new day's file:** read only yesterday and 2-days-ago files. Do NOT carry tasks from a "future" file created in a previous session — those tasks likely already exist in today's file or were handled separately.

## Date auto-generation (CRITICAL PITFALL)

**NEVER hardcode dates.** Always execute:
```
TZ='Asia/Jakarta' date +%Y-%m-%d
```
to get today's date before creating or updating any todo file. Do NOT guess or assume the date from the conversation history or system prompt.

**GOTCHA — System prompt date ≠ today's date:** The `Conversation started: Friday, May 29, 2026` line in the system prompt may be STALE. ALWAYS run `TZ='Asia/Jakarta' date +%Y-%m-%d` fresh — never trust the session start timestamp.

## Script Parsing Pitfalls

The morning/evening reminder scripts (`scripts/todo-reminder-morning.sh`, `scripts/todo-reminder-evening.sh`) must:

1. **Parse only the `## Tasks` section** — use `awk '/^## Tasks/{found=1; next} /^## /{found=0} found'` to extract tasks. Never grep the whole file, or you'll pick up lines from other sections.
2. **Clean task names properly** — use `sed 's/^- \[.\] [0-9]*\. //'` to strip the `- [ ] N. ` prefix. A bare `sed 's/^- \[ \\] //'` leaves the number and dot in the output.
3. **Count reliably** — use `grep -c .` with fallback `|| echo 0`. Empty variables should count as 0, not 1.
4. **Empty file check** — if no todo file exists for today, send "No to-do list today" message and exit.

## Telegram Topic Delivery

Cron `deliver=local` + Bot API direct via curl (Approach B). Never use `deliver=telegram:...` with `no_agent=true` — the wrapper text is unavoidable.

Topic delivery requires **numeric** chat_id + message_thread_id:
- ✅ `CHAT_ID="-1003966561389"` `THREAD_ID="5"` → Topic Notifikasi
- ❌ Named topic references don't work in curl — resolve numeric IDs via `send_message(action='list')` first
- If a send fails with "Could not resolve", retry with the numeric `chat_id:thread_id` format

## Done-Task Carry-Over Rule

**NEVER carry over tasks already marked `[x]` in ANY previous file.** When building today's todo:
1. Read the immediately previous day's file — only carry `[ ]` and `[~]` tasks
2. `[x]` tasks stay in old files as history, never reappear
3. If a user explicitly asks to re-add a done task, rewrite it as a NEW task with a new number (don't reuse the `[x]` checkmark)
4. When user provides a list that mixes done and pending (e.g., from an old todo), mark the done ones as `[x]` immediately in today's file — don't show them as pending in summaries

## Cron Delivery Architecture — CRITICAL GOTCHA

There are TWO approaches. Use **Approach B** (Bot API direct).

### ❌ APPROACH A: stdout + Hermes cron delivery (BROKEN — adds wrapper)

Setting `deliver: telegram:<chat_id>:<thread_id>` with `no_agent: true` causes Hermes to **wrap script stdout** with:

```
Cronjob Response: <job name>
(job_id: ...)
-------------
<actual script output>
To stop or manage this job, send me a new message...
```

**There is NO way to suppress this wrapper.** Do not use this approach.

### ✅ APPROACH B: Bot API Direct via curl (CLEAN — no wrapper)

Set `delivery: "local"` on the cron job (so Hermes doesn't send anywhere), and have the script send directly via `curl` to Telegram Bot API.

**Cron job config:**
```json
{
  "action": "create",
  "name": "To-Do Reminder Pagi",
  "schedule": "30 8 * * *",
  "no_agent": true,
  "script": "todo-reminder-morning.sh",
  "deliver": "local",
  "enabled_toolsets": []
}
```

**Script approach:**
```bash
#!/bin/bash
source /root/.hermes/.env   # reads TELEGRAM_BOT_TOKEN
CHAT_ID="-1003966561389"
THREAD_ID="5"
# ... parse todo file, build $MSG ...
curl -s "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage" \
  -d "chat_id=${CHAT_ID}" \
  -d "message_thread_id=${THREAD_ID}" \
  --data-urlencode "text=${MSG}" > /dev/null
```

**Key points:**
- `source /root/.hermes/.env` to read `TELEGRAM_BOT_TOKEN` from env file — never hardcode tokens in scripts
- `deliver: "local"` prevents Hermes from also sending script stdout → no double messages
- Redirect curl to `/dev/null` so script stdout stays clean

## Cron Job Tool Restrictions

Cron job agents with `no_agent: true` run with NO toolsets. Only the script executes. All file operations must be done via shell commands in the script itself.

## Stale Tagging Workflow

After carry-over, when building today's todo file:
1. Read **yesterday's** file — tasks carried from "yesterday" get `Origin: Carried (1 day)`
2. Read **2-days-ago** file — tasks carried from "2 days ago" get `⚠️` and `Stale: Yes`
3. A task becomes stale after **2 full days** of being pending
4. Format in Pending Details table: `⚠️ Stale` for stale tasks, `No` for fresh ones

## Script Parsing Pitfalls (CRITICAL)

The reminder scripts parse `todo-YYYY-MM-DD.md`. These pitfalls have caused broken output in production:

### 1. Parse ONLY the `## Tasks` section
**Wrong:** `grep '^\- \[ \]' "$FILE"` — matches lines in ANY section (Notes, Pending Details table, etc.)
**Right:** Use awk to isolate the section first:
```bash
TASKS_SECTION=$(awk '/^## Tasks/{found=1; next} /^## /{found=0} found' "$FILE")
PENDING=$(echo "$TASKS_SECTION" | grep '^\- \[ \]' | sed 's/^- \[ \] [0-9]*\. //' | grep -v "^$")
```

### 2. Strip task prefix correctly
**Wrong:** `sed 's/^- \[ \\] //'` — leaves the number (e.g., "1. Buat quotation...")
**Right:** `sed 's/^- \[ \] [0-9]*\. //'`

### 3. Count non-empty lines safely
**Wrong:** `echo "$PENDING" | grep -c . || true` — returns 0 on empty but also on error
**Right:** `echo "$PENDING" | grep -c . 2>/dev/null || echo 0`

### 4. Bash if-syntax
**Wrong:** `if [ ! -f "$FILE" then` — missing semicolon
**Right:** `if [ ! -f "$FILE" ]; then`

### 5. Evening script must exist
Both `scripts/todo-reminder-morning.sh` AND `scripts/todo-reminder-evening.sh` must exist.
If evening script is missing, the cron job (`To-Do Reminder Malam`) will fail silently.
The evening script should show "Done Today" FIRST (recap style), then pending/in-progress.

## Cron Reminder Languages: English Only

Both reminders use **English only** (no Indonesian/mix):

- Morning header: `To-Do Today — {Day}, {dd Month yyyy}`
- Evening header: `Summary To-Do Night — {Day}, {dd Month yyyy}`
- Section headers: `Done Today:`, `In Progress:`, `Pending:`
- Morning closing: `Have a productive day!`
- Evening closing: `Incomplete tasks carried over to tomorrow. Good night!`
- Summary line: `Summary: N done / N pending / N in progress`
- Empty file morning: `No to-do list today. Send tasks to OWL!`
- Empty file evening: `No to-do list today. Good night!`

**NOTE:** Previous versions used Indonesian. KII explicitly requested English on 2026-05-29.

## 🔴 In-Chat Summary Format: English Only

When sending a todo summary to Telegram (via `send_message`), **always use English** — same format as cron scripts:

```
📋 To-Do Today — Tuesday, June 02, 2026

🔄 In Progress:
• Task name

⬜ Pending:
• Task name

📊 Summary: N done / N pending / N in progress
```

- Date format: `{Day}, {Month} {dd}, {yyyy}` (e.g., "Tuesday, June 02, 2026")
- Do NOT use Indonesian words like "Hari Ini", "Selesai", "Pending" → must be "Done", "In Progress", "Pending"

## 🔴 Never Auto-Mark Done Based on Time

**NEVER mark a task as `[x]` done just because the scheduled time has passed.** A task is only done when KII explicitly says it's done (e.g., "done #3", "nomor 5 selesai", "mark done").

If KII only asks to edit/rename a task, do ONLY the rename — do NOT change the status.

## Telegram Topic Notifikasi Delivery

When sending todo summaries to Topic Notifikasi:
- **Target**: `telegram:MyAssistant24/7 / topic 5` (resolved via `send_message(action='list')`)
- **Chat ID**: `-1003966561389`, **Thread ID**: `5`
- Use `send_message(target='telegram:MyAssistant24/7 / topic 5', message='...')` directly

## Support Files

## Scripts

- `scripts/todo-reminder-morning.sh` — morning reminder (08:30 WIB), Bot API direct
- `scripts/todo-reminder-evening.sh` — evening recap (20:00 WIB), Bot API direct
- **Both must be kept in sync** — if one is updated (parsing logic, Bot API call), update the other too.
- **Both must be executable** — `chmod +x` after any edit.
- **Test after edits** — run `bash -n <script>` for syntax, then dry-run the parsing logic before relying on cron.
- `references/memory-tool-gotchas.md` — MEMORY.md/USER.md management pitfalls (drift recovery, capacity limits, § delimiter)
