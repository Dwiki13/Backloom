---
name: document-generator-go
description: Generate Quotation, Delivery Order, and Invoice using Go compiled binary. Reads YAML config, fills Excel template, converts to PDF, uploads to Google Drive. Use when user asks to create QTN/DO/INV documents.
category: productivity
---

# Document Generator (Go Version)

Generate business documents (Quotation, Delivery Order, Invoice) using the Go compiled binary at `/root/.hermes/docgen/`.

## Quick Usage

Always use the **compiled binary** (not `go run`):

```bash
cd /root/.hermes/docgen && ./docgen --config /path/to/config.yaml
```

## YAML Config Format

### Quotation
```yaml
type: quotation
client: PT Nama Perusahaan
person: Pak Nama
validity: 1 Week
delivery: 7-14 Hari
items:
  - desc: Nama Barang
    qty: 1
    uom: Pcs
    price: 1000000
  - desc: Barang Lain
    qty: 2
    uom: Unit
    price: 500000
```

### Delivery Order
```yaml
type: delivery_order
client: PT Nama Perusahaan
person: Pak Nama
po_number: PO/HAS/2026/05/001
po_date: 2026-05-29
delivery_date: 2026-06-01  # optional, defaults to today
items:
  - desc: Nama Barang
    qty: 1
    uom: Pcs
```

### Invoice
```yaml
type: invoice
client: PT Nama Perusahaan
person: Pak Nama
po_number: PO/HAS/2026/05/001
items:
  - desc: Nama Barang
    qty: 1
    uom: Pcs
    price: 1000000
```

## Workflow

1. **Create YAML config** in `/root/.hermes/docgen/` with `.yaml` extension
2. **Run binary**: `cd /root/.hermes/docgen && ./docgen --config <filename>.yaml`
3. **Outputs**:
   - Excel: `/root/.hermes/output/<Client>_<DocNumber>.xlsx`
   - PDF: `/root/.hermes/output/<Client>_<DocNumber>.pdf`
   - Uploaded to Google Drive subfolder (Quotation/DO/Invoice) under PT folder
   - Telegram notification sent automatically
4. **Send files to user** via `send_message` with `MEDIA:` path

## Template Layout (Quotation)
- Row 14: B14:O14 = "QUOTATION" title (merged)
- Row 16: J16:K16 = "No Quotation :" / L16:O16 = doc number
- Row 17: J17:K17 = "Tanggal :" / L17:O17 = date
- Row 18: B18 = "Kepada Yth :"
- Row 19: Client name + "Up. Person"
- Row 24: Headers (No, Description, Qty, Uom, Harga, Total)
- Row 25+: Item data rows
- Row after items: Sub Total, Grand Total (NO PPN row — template doesn't have it)
- Note rows: Validity, Delivery Time (shifted down for extra item rows)
- Row 40+: Bank info, sign-off

## Key Code Details
- **Source**: `/root/.hermes/docgen/main.go`, `generator.go`, `config.go`, `parser.go`, `uploader.go`, `notifier.go`
- **Binary**: Rebuild with `cd /root/.hermes/docgen && go build -o docgen .`
- **Template download**: Auto-downloads from GDrive folder `10Ix63pMDiIELx-4qaOu-T9UwR2TYgg_r`, falls back to `/root/.hermes/templates/`
- **OAuth**: `/root/.hermes/credentials/gdrive-oauth-token.json` + `gdrive-oauth-client.json`
- **Tracker**: `/root/.hermes/data/document-tracker.json` (shared with Python version)
- **Border strategy**: Keep template row 25 as style source, copy styles to inserted rows via `copyRowStyles()`
- **PPN**: NOT shown separately — Grand Total includes everything

## After Generation
Always:
1. Send Excel file to user via `send_message` with `MEDIA:/root/.hermes/output/<file>.xlsx`
2. Send PDF file to user via `send_message` with `MEDIA:/root/.hermes/output/<file>.pdf`
3. Send Drive links in text message