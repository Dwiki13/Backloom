---
name: forex-trading
description: "Forex trading strategy development, backtesting, and signal bot management. Covers broker account types (Cent/Standard/Raw), pip/point calculations, lot sizing, risk management, ICT/smart money concepts, multi-strategy backtesting, and building Telegram-signal bots with multi-source data feeds."
version: "1.8.0"
author: OWL Agent
---

# Forex Trading

Build and maintain trading tools: backtesting engines, signal bots, broker configs, and risk calculators.

## Trigger

Use this skill when the user talks about:
- Forex trading, XAUUSD, gold, currency pairs
- Broker accounts (Exness, HFM, XM, etc.)
- Pip/lot/risk calculations
- Trading strategies (ICT, EMA, MACD, London Breakout, etc.)
- Signal bots, Telegram alerts, backtesting
- Trading journal management
- gold-api.com API (OHLC, price, history endpoints)

### Broker-Specific Math (CRITICAL — Do NOT Assume Defaults)

**Always ask the user to confirm their broker's actual values.** Pip definitions vary wildly across brokers.

**Session-Specific Update from KII (May 28, 2026):** For HFM Cent account:
- Format: 2 decimals (4439.00)
- **Pip convention: 100 points = 10 pips** (i.e. 1 pip = 10 points)
- Lot 0.01 → 1 pip = **0.1 cent** ($0.001)
- **10 pips × 0.01 lot = 1 cent** — confirmed by user testing
- Spread: **35 points = 3.5 pips**
- **Entry/SL/TP display: USD format** (e.g. `4374.50`) — NOT converted to cent
- **Risk/PnL/balance display: cent** (e.g. `1000c`, `1.5c`)
- **Entry Area**: ±20p around spot price (e.g., `4428.10 - 4432.10 (±20p)`)
- **SL/TP for gold: 100p/150p/200p** (RR 1:1.5 and 1:2)

### Key Definitions

| Term | Meaning | Varies by broker? |
|------|---------|-------------------|
| **Pip** | Smallest standard price move | YES — can be 1 pip = 10 points or 1 pip = 1 point |
| **Point** | Smallest visible digit on chart | Usually 1 digit of the last decimal |
| **Spread** | Bid-ask gap | Quoted in points, cost = lot × pip_value × spread_points |

### HFM Cent — XAUUSD (Active Account):
- Format: 2 decimals (4439.00)
- **Pip convention: 100 points = 10 pips** (i.e. 1 pip = 10 points)
  - 1000 points = 100 pips | 100 points = 10 pips | 10 points = 1 pip
- Lot 0.01 → 1 pip = **0.1 cent** ($0.001)
- **10 pips × 0.01 lot = 1 cent** — confirmed by user testing
- Spread: **35 points = 3.5 pips**
- Balance: $17.68 (1767.98c) as of 2026-05-29
- **Entry/SL/TP display: USD format** (e.g. `4374.50`) — NOT converted to cent
- **Risk/PnL/balance display: cent** (e.g. `1000c`, `1.5c`)
- **Entry Area**: ±20p around spot price (e.g. `4428.10 - 4432.10 (±20p)`)
- **SL/TP for gold: 100p/150p/200p** (RR 1:1.5 and 1:2)
  - Gold daily range is large; SL must have breathing room
  - 100 pip SL = $10 buffer from entry
  - TP1 150p (RR 1:1.5), TP2 200p (RR 1:2)
  - User may modify per trade (e.g., wider SL, partial TP)

### Exness Cent — XAUUSD:
- Format: 3 decimals (3285.500)
- 1 pip = 10 points
- Lot 0.01 → 1 pip = $0.001 (0.1 cent)
- 10 pips × 0.01 lot = $0.01 (1 cent)
- Spread: ~28 pips

### Universal Calculation Pattern

```python
cent_multiplier = 100   # 1 USD = 100 cent
pip_to_points = 10      # 1 pip = how many points?
pip_value_001 = 0.1     # cent per pip per 0.01 lot ($0.001 = 0.1 cent)

# Risk / TP in cent (correct formula):
risk_cent = (lot / 0.01) * sl_pips * pip_value_001
tp_cent   = (lot / 0.01) * tp_pips * pip_value_001
```

```python
# Points → price offset: 1 point = 0.01 USD
sl_price  = entry - sl_points * 0.01   # for BUY (SL below entry)
tp1_price = entry + tp1_points * 0.01  # for BUY (TP above entry)
# For SELL: flip +/-
```

### Common Pitfall: Direction in price_from_pips

```python
def price_from_pips(entry, pips, direction):
    """Price offset: direction="BUY" → below entry, direction="SELL" → above entry"""
    offset = pips2pts(pips) * 0.01
    if direction == "BUY":
        return entry - offset  # SL below entry for BUY
    else:
        return entry + offset  # SL above entry for SELL

def tp_from_pips(entry, pips, direction):
    """Price offset: direction="BUY" → above entry, direction="SELL" → below entry"""
    offset = pips2pts(pips) * 0.01
    if direction == "BUY":
        return entry + offset  # TP above entry for BUY
    else:
        return entry - offset  # TP below entry for SELL
```

**⚠️ CRITICAL:** In `_build_signal`, ALWAYS call both `price_from_pips` and `tp_from_pips` with the SIGNAL direction (e.g., `"BUY"`). Do NOT swap to opposite direction — the functions already handle correct placement internally.

```python
# CORRECT:
"sl_price": round(price_from_pips(entry, sl_p, direction), 2),    # direction = signal direction
"tp1_price": round(tp_from_pips(entry, tp1_p, direction), 2),    # direction = signal direction
"tp2_price": round(tp_from_pips(entry, tp2_p, direction), 2),    # direction = signal direction
```

### Entry Area Calculation

```python
area_pips = 20  # ±20 pips around entry
area_offset = pips2pts(area_pips) * 0.01  # 20pts * 0.01 = 0.20 USD
entry_lo = round(entry - area_offset, 2)
entry_hi = round(entry + area_offset, 2)
# Display: "Entry Area: {entry_lo} - {entry_hi} (±20p)"
# Note: entry_lo < entry_hi always (low - high order)
```

### Common Pitfall: Risk Formula Wrong

WRONG: `risk = lot * sl_pips * pip_value` → gives tiny values (0.01c)
RIGHT: `risk = (lot / 0.01) * sl_pips * pip_value` → gives correct cent values

### Common Pitfall: Float Formatting

```python
# WRONG — causes ValueError: Unknown format code 'd' for object of type 'float'
bal_str = f"{bal:.1f}" if bal != int(bal) else f"{bal:+d}"  # bal is always float!
pnl_str = f"{pnl:+.1f}" if pnl != int(pnl) else f"{pnl:+d}"  # same bug

# RIGHT — always use .1f for balance/PnL display
bal_str = f"{bal:.1f}"
pnl_str = f"{pnl:+.1f}"
```

### PnL Calculation — Use ACTUAL Prices (Critical Correction May 29 2026)

**KII corrected: PnL must be calculated from ACTUAL entry and exit prices, NOT from theoretical pip values.**

Theoretical: entry 4535.60, TP1 4550.60 = 150 pips = 75c (lot 0.05)
Actual: entry 4537.78, TP1 ~4548.68 = ~109 pips = 64.10c (lot 0.05)

**When KII reports results, ALWAYS use the actual PnL values he provides.** Do not recalculate from theoretical pip distances. The difference comes from:
- Entry price may differ from bot's spot price (KII picks within entry area)
- TP may be hit at different price level than theoretical (slippage, partial fills)
- Broker pricing differences

When updating journal from KII's report:
1. Use exact PnL value KII provides (e.g., "WIN 64.10" → `pnl_cent: 64.10`)
2. Update `entry_price` to actual entry if KII provides it
3. Note position number if multiple positions on same signal
4. **Per-position results are reported incrementally** — KII may report Pos 1 first, then pos 2 later. Update positions array as info arrives.
5. **Remove signal entries KII did not trade** (cron may auto-generate signals KII skips)

### BE Classification (Break-Even) — Added May 30 2026

**A position is BE (not W) when the profit is negligible** — typically < 10c for lot 0.05 (equivalent to ~2 pips or less). KII determines BE status; the bot does not auto-classify.

**Rule of thumb:**
- Profit ≤ 10c with lot 0.05 → likely BE (KII confirms)
- Profit ≤ 5c with lot 0.01 → likely BE
- Any profit that doesn't meaningfully cover spread + slippage → BE

**When KII says a position is BE:**
1. Change `result` from `"W"` to `"BE"` in the positions array
2. Update `note` to include "(BE, profit tipis)"
3. Increment `stats.be` by 1 (do NOT change `stats.wins`)
4. `signal_pnl` stays the same (BE profit still counts toward signal total)
5. Signal-level result: if all positions are BE and net PnL ≈ 0 → signal is BE

**Journal correction example (May 30 2026):**
```json
// Before fix:
{"pos": 3, "result": "W", "pnl": 7.3}  // signal_pnl: 127.35, be: 0
// After KII confirmed BE:
{"pos": 3, "result": "BE", "pnl": 7.3, "note": "Exit 4538.76 (BE, profit tipis)"}  // be: 1
```

**⚠️ PITFALL:** Bot auto-generates all positions as "W" when TP is checked. KII manually corrects BE status. Always ask KII for position-level results rather than assuming all hit TP.

### Win Rate Calculation — Per Signal (Corrected May 29 2026)

**KII confirmed: Win rate is counted PER SIGNAL, not per position.**

- 4 signals, 1 win (even if that win has 3 positions) = 25% WR
- `stats.wins` = count of signals where net PnL is positive
- `stats.losses` = count of signals where net PnL is negative
- `stats.win_rate` = wins / total_signals * 100 (integer)

**KII's counting method:**
- If ANY position in a signal is W with net positive PnL → that signal counts as 1 Win
- If ALL positions lose → that signal counts as 1 Loss
- BE (net zero PnL across all positions) → counted as neither (excluded from WR)

The `stats` JSON: wins/losses are per-signal counts, win_rate = wins/total_signals*100.

**⚠️ IMPORTANT for `fmt_journal_summary()`:** The stats key is `total_signals` (not `total`). The function must handle both:
```python
total = st.get("total_signals", st.get("total", 0))
```

### Multiple Positions Per Signal

**KII often opens multiple positions on a single bot signal** (typically 2-3 entries at different prices within the entry area). Each position may have a different outcome.

**Journal format (Updated May 29 2026):** Use nested `positions[]` array within each signal entry. Do NOT create separate top-level entries for each position.

When KII reports results:
1. Add all positions under the same signal entry in the `positions[]` array
2. Each position stores: actual entry price, actual outcome (W/L/BE), actual PnL, lot size
3. Set `signal_pnl` = sum of all position PnL
4. Signal result = W if signal_pnl > 0, L if < 0, BE if == 0
5. Only set signal `status: "CLOSED"` when ALL positions are closed/reported
6. **If KII says "remove" for cron-generated signals KII didn't trade — remove them entirely**

### Journal JSON Schema (Multi-Position Format)

```json
{
  "account": "HFM Cent",
  "currency": "cent",
  "start_balance_cent": 1447.23,
  "balance_cent": 1767.98,
  "balance_start_date": "2026-05-28",
  "signals": [
    {
      "signal_id": 1,
      "timestamp": "2026-05-28T13:06:23+00:00",
      "strategy": "London Breakout",
      "direction": "BUY",
      "positions": [
        {"pos": 1, "entry": 4431.68, "sl": 4421.74, "lot": 0.05, "result": "L", "pnl": -49.7}
      ],
      "signal_pnl": -49.7,
      "status": "CLOSED"
    },
    {
    "signal_id": 4,
    "timestamp": "2026-05-29T13:52:54+00:00",
    "strategy": "NY Open Momentum",
    "direction": "BUY",
    "positions": [
      {"pos": 1, "entry": 4537.78, "tp1": 4550.60, "lot": 0.05, "result": "W", "pnl": 64.10},
      {"pos": 2, "entry": 4539.42, "tp1": 4550.60, "lot": 0.05, "result": "W", "pnl": 55.95},
      {"pos": 3, "entry": 4537.30, "exit": 4538.76, "lot": 0.05, "result": "BE", "pnl": 7.30, "note": "Exit 4538.76 (BE, profit tipis)"}
    ],
    "signal_pnl": 127.35,
    "status": "CLOSED"
    }
    ],
    "stats": {
    "total_signals": 4,
    "wins": 1,
    "losses": 3,
    "be": 1,
    "win_rate": 25,
    "pnl_cent": -149.55
    }
}
```

**Key fields:**
- `signals[].positions[]` — array of individual position results within one signal
- `signal_id` — unique signal identifier (increments per signal, not per position)
- `signal_pnl` — sum of all position PnL for this signal
- `stats.wins` / `losses` — counted PER SIGNAL (not per position)
- `stats.win_rate` — wins / total_signals * 100 (integer)
- `balance_cent` — ALWAYS reflects actual HFM broker balance (includes manual trades outside bot)
- Bot PnL (stats.pnl_cent) ≠ balance change when KII does manual trades

## Data Sources (Updated — May 28, 2026)

### Source Priority for Real-Time Spot Price

**⚠️ CRITICAL: Cache gold-api.com for 30 seconds.** The API docs explicitly warn: "spamming the endpoint will result in your IP being blocked."

```
1. api.gold-api.com /price/XAU/USD — PRIMARY (free, no auth, cache 30s)
2. GoldAPI.io /api/XAU/USD — FALLBACK (needs key)
3. Binance PAXG/USDT — FALLBACK (real-time, no key)
4. yfinance GC=F — LAST RESORT (delayed ~15min)
```

### gold-api.com Endpoint Details

| Endpoint | Auth | Rate Limit | Granularity | Use For |
|----------|------|------------|-------------|---------|
| `/price/XAU/USD` | None | None (cache 30s) | Real-time spot | Spot price display |
| `/ohlc/XAU` | API key | 10 req/hr | **Aggregated per period** (min ~12h windows) | Daily/weekly range only |

**⚠️ CRITICAL FINDING:** `/ohlc` returns AGGREGATED OHLC for the entire requested period, NOT per-candle. NOT suitable for per-hour breakout detection — use yfinance 1H candles instead.

### Price Delay Warning

gold-api.com has approximately **5-10 minute price delay**. Acceptable for swing/day trading but NOT for scalping. For real-time breakout detection, prefer yfinance 1H candles or Binance PAXG.

## Signal Output Format — CENT Account (CRITICAL)

**KII explicitly corrected this — DO NOT convert entry/SL/TP to cent.**

For cent accounts, entry/SL/TP prices stay in **USD format** (readable directly on broker app). Only balance, risk, and PnL are displayed in cent.

**Rules:**
- Entry/SL/TP: **always USD format** (e.g. `4374.50`)
- Use `↑`/`↓` arrows to indicate direction relative to entry
- Show pips in shorthand: `40p`, `60p`, `100p`
- Balance/risk/PnL: **always cent** with `c` suffix
- Include data source tag (e.g. `📡 gold-api.com`)
- Include journal summary + reply instructions when signal is active
- **Show full lot reference table** — user picks their own lot

### ✅ CORRECT Format (KII preferred — Updated May 29 2026):

```
🔴 SELL XAUUSD — London Breakout
Confidence: 🔥 HIGH | ⏰ 2026-05-28 16:00 WIB | gold-api.com

💰 Entry Area: 4428.10 - 4432.10 (±20p)
🛑 SL: ↓100p = 4420.10
🎯 TP1: ↑150p = 4435.10
🎯 TP2: ↑200p = 4450.10

📦 Lot reference (pilih sesuai nyaman):
  0.01 → risk 10c | TP1 +15c | TP2 +20c
  0.02 → risk 20c | TP1 +30c | TP2 +40c
  0.05 → risk 50c | TP1 +75c | TP2 +100c
  0.10 → risk 100c | TP1 +150c | TP2 +200c

💰 Balance: 1767.98c ($17.68)

📝 Setup:
  • Opening range: 4415.60 - 4424.80
  • Range: 92 pips
  • breakout: above

📒 Journal Summary
📊 Total:4 W:1 L:3 | WR:25% | PnL:-150c | Bal:1767.98c
📝 Reply: W / L / BE
```

**Format Rules (KII confirmed):**
- NO `━━━━━━━━━━━━━━━━━━━━` divider lines — use blank lines instead
- NO header/footer wrappers from the delivery layer
- Spot source inline with timestamp (e.g., `| gold-api.com`)
- Compact single-line for no-signal status: `📊 XAUUSD 09:00 WIB | $4508.10 | off-hours | PnL: 0c/100c | waiting`
- The `log()` function must NOT print to stdout — only to file. stdout = Telegram message only.

## Cron Delivery — send_tg() Fix (June 1, 2026)

**⚠️ CRITICAL: Telegram topic/thread requires `message_thread_id` as a SEPARATE API parameter.**

**WRONG** — appending thread to chat_id:
```python
json={"chat_id": "-1003966561389:334", "text": msg}  # Goes to General/DM!
```

**RIGHT** — separate params:
```python
json={"chat_id": "-1003966561389", "message_thread_id": "334", "text": msg}
```

**Implementation in `send_tg()`:**
```python
def send_tg(msg):
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID: return False
    try:
        chat_id = TELEGRAM_CHAT_ID
        params = {"chat_id": chat_id, "text": msg}
        if ":" in str(chat_id):
            parts = str(chat_id).split(":", 1)
            params["chat_id"] = parts[0]
            params["message_thread_id"] = parts[1]
        r = requests.post(
            f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage",
            json=params, timeout=15)
        log(f"Telegram {'OK' if r.status_code==200 else 'FAIL:'+str(r.status_code)}")
        return r.status_code == 200
    except Exception as e:
        log(f"Telegram error: {e}"); return False
```

**Verification:** `telegram:MyAssistant24/7 / topic 334` resolves to chat_id `-1003966561389`

## .env File Loading

**Bot must explicitly load `.env` file** — `os.environ.get()` alone doesn't read `.env` files. Without this, `TELEGRAM_BOT_TOKEN` is always empty → `send_tg()` returns False silently.

```python
_env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
if os.path.exists(_env_path):
    with open(_env_path) as _f:
        for _line in _f:
            _line = _line.strip()
            if _line and not _line.startswith("#") and "=" in _line:
                _k, _v = _line.split("=", 1)
                _k = _k.strip()
                _v = _v.strip().strip('"')
                if _k == "TELEGRAM_BOT_TOKEN" and not TELEGRAM_BOT_TOKEN:
                    TELEGRAM_BOT_TOKEN=***                elif _k == "TELEGRAM_CHAT_ID" and not TELEGRAM_CHAT_ID:
                    TELEGRAM_CHAT_ID = _v
```

## Cron Duplicate Prevention

**⚠️ NEVER manually trigger `cronjob run` for the signal bot during live trading.** It creates duplicate signals AND duplicate journal entries. Manual triggers should only be used for testing code changes, NEVER during live trading hours.

## Cron Delivery Pattern

**Current working config (June 2, 2026):**
- Schedule: `0 15,16,17,18,19,20,21,22,23 * * *` WIB (9x/day)
- Delivery: `local` — bot handles Telegram internally via `send_tg()`
- Topic: `telegram:-1003966561389:334` (MyAssistant24/7 group, topic 334 — Topic Trading)
- Chat ID: `-1003966561389`
- **Source path**: `/root/projects/trading/xauusd-bot/xauusd_multi_session.py` (NEVER `/root/xauusd-bot/`)
- **Journal path**: co-located with source at `/root/projects/trading/xauusd-bot/trading_journal.json`

**No agent relay needed** — bot's `print()` outputs to stdout (for logging), `send_tg()` sends directly to Telegram topic.

## Signal Bot Architecture (Updated)

### Market Structure Filter (Added May 29 2026)

After generating a signal, the bot analyzes market structure and filters signals against the trend:

```python
# In main(), after getting sig from any strategy:
if sig:
    structure, _, _ = analyze_market_structure(candles)
    if not filter_by_trend(sig['direction'], structure):
        log(f"Blocked {sig['direction']} against {structure} trend")
        sig = None  # Let next strategy try

# After formatting message, append loss review:
loss_review = get_loss_review(candles)
if loss_review:
    msg = msg + "\n\n" + loss_review
```

**filter_by_trend rules:**
- Block SELL signals during uptrend (HH+HL detected)
- Block BUY signals during downtrend (LH+LL detected)
- Allow all signals during ranging market

**Loss Review (appended to signal message when triggered):**
- Triggered when ≥2 recent losses in same direction
- Cross-references with market structure
- Example: "LOSS REVIEW: Market UPTrend (HH+HL) | SELL loss 4x | Fokus BUY dalam uptrend"

### Balance Sync Protocol (Critical)

**⚠️ The bot's `C["balance_cent"]` does NOT auto-update from the journal.** When KII manually trades (outside the bot), the bot's internal balance diverges from actual broker balance.

**When KII reports a balance update:**
1. Update `C["balance_cent"]` in `/root/projects/trading/xauusd-bot/xauusd_multi_session.py`
2. Update `balance_cent` in `/root/projects/trading/xauusd-bot/trading_journal.json`
3. Do NOT change `stats.pnl_cent` — that tracks cumulative PnL from bot signals only

**The journal's `balance_cent` should always reflect the ACTUAL broker balance**, not the bot's internal tracking. When in doubt, ask KII for the current balance.

## Trading Strategies

### 1. London Breakout (Primary)
- **Session**: 15:00-22:00 WIB
- **Setup**: Capture high/low of 15:00 WIB hour → breakout = entry
- **Entry**: Market price after breakout confirmed (close above/below range + 0.05 buffer)
- **SL**: 100 pips | **TP1**: 150 pips (1:1.5) | **TP2**: 200 pips (1:2)
- **Entry Area**: ±20p around spot/entry price
- **Min range**: 0.3 USD (3 pips) to avoid noisy sessions

### 2. NY Open Momentum
- **Session**: 20:00-23:00 WIB
- **Setup**: First candle of NY session (20:00) direction = trade direction
- **SL**: 100 pips | **TP1**: 150 pips | **TP2**: 200 pips

### 3. Asian Range Breakout (Safest)
- **Session**: 00:00-08:00 WIB range → breakout during 12:00-21:00 WIB
- **Setup**: Tight Asia range (< 30 pips) → breakout = entry
- **SL**: 100 pips | **TP1**: 150 pips | **TP2**: 200 pips

## Daily Target Management

KII's rule: **$1 minimum, $2 maximum per day.** Bot must enforce this.

```python
"daily_target_min": 100,  # $1 = 100 cent
"daily_target_max": 200,  # $2 = 200 cent (HARD STOP)
```

## Position Sizing — Dynamic Lot for Target

```python
# Lot for target risk: lot = target_cent / (sl_pips * 10)
# Derived from: target = (lot/0.01) * sl_pips * 0.1
# Simplifies to: lot = target_cent / (sl_pips * 10)
suggested_lot = max(0.01, round(target_cent / (sl_pips * 10), 2))
suggested_lot = min(suggested_lot, 0.10)  # Cap for $10 account
```

| Target/Day | Lot | Risk/Trade (100p SL) | TP1 (150p) | TP2 (200p) | Trades Needed |
|------------|-----|---------------------|-----------|------------|---------------|
| ~$0.50 (50c) | 0.01 | 10c | 15c | 20c | 3-5x |
| ~$1 (100c) | 0.05 | 50c | 75c | 100c | 1-2x |
| ~$2 (200c) | 0.10 | 100c | 150c | 200c | 1x |

## Journal Continuity Protocol (Updated June 1, 2026)

**⚠️ Journal signal IDs MUST continue incrementing across days. Never reset to #1.**

- Day 1: signals #1-#5
- Day 2: signals #6-#9 (continue from last ID)
- Day 3: signals #10+ (continue from last ID)

**When cleaning up the journal** (e.g., removing duplicates):
1. Remove unwanted entries
2. Re-number ALL remaining entries sequentially from #1
3. Recalculate stats based on the cleaned list
4. When adding new signals, always use `max(existing_ids) + 1` as the next ID

**When restoring old signals** (e.g., after accidental deletion):
1. Insert old signals with their original IDs
2. Re-number everything sequentially
3. Continue new signals from the new max ID

**Current journal state (as of June 1, 2026, 23:30 WIB):**
- 9 signals total (#1-#9)
- W:4 L:4 BE:1 | WR:44% | PnL:+550.45c → then +1150.45c after #8/#9 updates
- Balance: 1520.83c (KII manual update, includes trades outside bot)
- Formula: `start_balance_cent + stats.pnl_cent = KII's actual balance`

## Journal Format — Actual Implementation (Updated June 1, 2026)

**The live journal uses FLAT entries (one per signal), NOT nested `positions[]`.** Each signal entry stores the net PnL directly. The nested positions schema described above is aspirational but not currently implemented.

### Actual journal_add() code pattern:
```python
j["signals"].append({
    "id": len(j["signals"]) + 1,
    "timestamp": datetime.now(timezone.utc).isoformat(),
    "strategy": sig["strategy"],
    "direction": sig["direction"],
    "entry_price": sig["entry_price"],
    "sl_price": sig["sl_price"],
    "tp1_price": sig["tp1_price"],
    "tp2_price": sig["tp2_price"],
    "lot": sig["lot_suggestion"],
    "sl_cent": sig["sl_cent"],
    "tp1_cent": sig["tp1_cent"],
    "tp2_cent": sig["tp2_cent"],
    "result": None,       # Updated manually by KII report
    "pnl_cent": None,     # Updated manually
    "note": "",
    "status": "OPEN",
})
```

**ID continuity:** Use `max(existing_ids, default=0) + 1` instead of `len(j['signals']) + 1` to prevent duplicate IDs when signals are deleted or from race conditions. See Bug Fix #15 below.

### Multi-Position Result Recording
When KII trades multiple positions on one signal, sum all position PnL into a single `pnl_cent` value on the signal entry. Record the breakdown in `note`:
```
"4 posisi: 2W(TP2, lot 0.05) + 2L(SL, lot 0.05) = +100c"
```

## Balance Reconciliation Formula (Updated June 1, 2026)

**When KII reports a balance update from manual trading:**

The journal tracks its own PnL (`stats.pnl_cent`) from bot-signaled trades only. KII's manual trades affect the real broker balance but are NOT in the journal.

To keep the journal's `start_balance_cent` consistent with reality:
```python
# KII reports current actual balance (e.g., 1520.83c)
# Journal's stats.pnl_cent = sum of all bot trade results (e.g., +550.45c)
# Formula: journal should show start + pnl = current_actual
# So: start_balance_cent = current_actual - stats.pnl_cent

j["start_balance_cent"] = round(kii_reported_balance - j["stats"]["pnl_cent"], 2)
```

This ensures `start_balance_cent + stats.pnl_cent = KII's actual balance` at all times.

- **"langsung aja bro"** = just do it, no lengthy explanations
- **No fluff** — give direct answers, skip pleasantries
- **"gua balikin ke elu"** = "I'm throwing it back to you" — KII wants YOUR recommendation, not more questions.
- **Cron delivery target**: `telegram:-1003966561389:334` (MyAssistant24/7 group, topic 334)
- **No signal ≠ no message**: Bot should ALWAYS send something — either signal or "no signal" status.

## Bug Fixes & Learnings

0. **DATA_DIR must be dynamic** — Hardcoded `DATA_DIR = "/root/xauusd-bot"` causes the bot to read/write journal and log from a DIFFERENT folder than the source code. When source is at `/root/projects/trading/xauusd-bot/` but DATA_DIR points to `/root/xauusd-bot/`, the bot reads an old/empty journal → wrong signal IDs (restarting from #1), WR=N/A, empty stats. **Fix:** `DATA_DIR = os.path.dirname(os.path.abspath(__file__))` so journal/log/signal are always co-located with the source script. Same for `.env` loading.

0b. **fetch_intraday period too short** — `period="3d"` yields only ~36 1H candles, which is insufficient for reliable swing high/low detection (often <2 swing points → always "ranging"). **Fix:** Use `period="5d"` (~76 candles) so `analyze_market_structure` gets enough data.

0c. **analyze_market_structure lookback too small** — Default `lookback=20` often catches only 1 swing low, causing false "ranging" classification that lets counter-trend signals through. **Fix:** `lookback=40`. Also add SMA10 fallback: when swing points < 2, compare close vs SMA10 (±0.5% threshold) to estimate trend.

0d. **Cronjob must run from source path** — Cron must execute `python3 /root/projects/trading/xauusd-bot/xauusd_multi_session.py`, NEVER from `/root/xauusd-bot/` (that folder is legacy/empty). Copying files between folders causes journal divergence.

0e. **Journal co-located with source** — Since DATA_DIR is dynamic, `trading_journal.json`, `bot.log`, and `latest_signal.json` all live in `/root/projects/trading/xauusd-bot/`. Do NOT create a separate runtime folder.

1. **price_from_pips/tp_from_pips direction bug**: Pass SIGNAL direction to both functions, NOT opposite.
2. **Float formatting**: Always use `f"{value:.1f}"` for balance/PnL. NEVER use `f"{value:+d}"` on floats.
3. **Cron timezone**: Always UTC, never WIB. Convert: UTC = WIB - 7.
4. **Token masking**: System auto-masks bot tokens when written to files. Use agent `send_message` tool for Telegram delivery.
5. **Balance display**: Use `f"{balance}c (${balance/100:.2f})"` — NOT `:.0f` which truncates decimals.
6. **JSON syntax**: Always compile Python scripts after edits (`python3 -m py_compile script.py`).
7. **Cron slot miss**: If current time has passed UTC slots, cron skips them. Trigger manual run if needed.
8. **KII reports multi-position results gradually**: Update positions[] array incrementally using KII's exact PnL numbers.
9. **Win rate calculation**: stats.wins / stats.total_signals * 100 (per SIGNAL, not per position). Key is `total_signals` not `total`.
10. **Stats format**: Use `total_signals` key (not `total`). `fmt_journal_summary()` must handle both via `.get()`.
11. **Remove untraded signals**: If KII says cron generated signals he didn't trade, remove them from journal entirely.
12. **Cron delivery unreliable**: Agent-based cron adds meta-text. Best approach: run bot manually and send via `send_message` tool.
13. **BE vs W classification**: Bot marks all TP-hit positions as "W". KII may reclassify negligible-profit positions as "BE". When KII says BE: update `result` to "BE", add "(BE, profit tipis)" note, increment `stats.be`. `signal_pnl` unchanged (BE profit still counts toward signal net).
15. **journal_add ID generation**: Use `max(existing_ids, default=0) + 1` NOT `len(signals) + 1`. The len-based approach produces duplicate IDs when signals are deleted or when the journal is read from a stale/cached file. Always compute next ID from actual existing IDs in the loaded journal.

16. **Manual balance update (no journal entry)**: When KII reports manual trading profit/loss that should NOT affect WR/stats: (1) update `C["balance_cent"]` in the script config, (2) update `balance_cent` in `trading_journal.json`, (3) do NOT create a journal signal entry, (4) do NOT change `stats.pnl_cent` or `stats.wins/losses/be`. This keeps the bot's balance display accurate without polluting the signal statistics.

17. **Multi-position per signal**: KII often opens 3-5 positions on a single signal at slightly different entry prices within the entry area, with different TP levels (some TP1, some TP2). Record the breakdown in the signal's `note` field: `"5 pos: 3xTP1 + 2xTP2, lot 0.05"`. The signal's `pnl_cent` = sum of all position PnL. `lot` field = total lot (e.g., 0.25 for 5x0.05).

## Strategy Design Decisions (June 2, 2026)

**Market structure filter settings — KII decided to keep original values after discussion:**
- `analyze_market_structure` lookback = **20** (not 40)
- `fetch_intraday` period = **3d** (not 5d)
- No SMA fallback for trend detection
- Strict `filter_by_trend` (block counter-trend signals entirely)

**Rejected alternatives (for reference):**
- Scoring system (trend + range quality + loss review + market structure) — too complex for now
- Multi-timeframe trend filter (H4/Daily) — user preferred keeping it simple on H1
- SMA10 fallback when swing points < 2 — not needed with strict block approach

**Rationale:** Keep the bot simple. The strict block approach (block SELL in uptrend, block BUY in downtrend) is sufficient. If swing detection fails to find enough points, the signal passes through (ranging = allow all). This is acceptable behavior — better to allow a counter-trend signal than to block a valid one with a false trend reading.

## Reference Files
- `references/session-learnings-0529.md` — Session-specific corrections (May 29 2026) including WR calculation, report format, balance protocol
- `references/session-learnings-0601.md` — June 1 2026: journal flat format confirmation, balance reconciliation formula, send_tg() fix, duplicate prevention, daily recap cron
- `references/cent-account-math.md` — Cent account math reference
- `references/backtest-results-0529.md` — ICT Default vs Bot Current backtest (May 29 2026)
- `references/api-gold-api-com.md` — gold-api.com API documentation
- `references/ict-session-times.md` — ICT session times reference
- `references/backtest-results.md` — Full backtest results