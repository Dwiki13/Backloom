---
name: forex-ea-mt5
description: Build and deploy MetaTrader 5 Expert Advisors (EA) for forex auto-trading — covers MQL5 development, signal generation from Python/OWL, and Linux VPS deployment constraints.
---

# Forex EA (MT5) Skill

Build Expert Advisors for MetaTrader 5 that receive trading signals and auto-execute orders.

## Architecture

Two common patterns:

1. **File-based signals (recommended for VPS)**: Python script writes signals to a shared file → EA reads file on each tick → executes. Both run on same VPS.
2. **Python direct via MT5 API**: `MetaTrader5` Python library controls MT5 terminal directly. Requires MT5 terminal running via Wine+Xvfb on Linux.

## Linux VPS Constraints

- MT5 is Windows-only → needs **Wine + Xvfb** on Linux
- Wine install: `apt install wine64` + `apt install xvfb`
- **⚠️ CRITICAL: MT5 GUI installer does NOT work on headless VPS.** Running `wine mt5setup.exe /silent` silently fails (no error, no installation). Wine returns `nodrv_CreateWindow` / `kernel32.dll` errors. There is no workaround — Wine without display driver cannot render any Windows GUI installer.
- **MetaEditor (MQL5 compiler) is also GUI** → cannot compile `.mq5` on headless VPS either.
- **Practical workaround**: Develop `.mq5` source on VPS, send to user, they compile on their local Windows MT5 installation. The `.ex5` binary can be copied back to the Wine prefix if MT5 is already installed by other means.
- If MT5 is already installed (e.g., copied from another machine), the EA can run — but **compiling** must happen on a GUI-capable machine.
- Virtual display: `Xvfb :99 -screen 0 1024x768x24 -ac &` then `export DISPLAY=:99`
- Wine binary path: `/usr/bin/wine` (NOT `wine64` command)
- pip installs (numpy, pandas, yfinance) can be very slow — may timeout
- **Yahoo Finance API is rate-limited from most VPS IPs** — returns 404
- Many free forex data APIs are also blocked/rate-limited from cloud VPS IPs
- Consider: signal-only bot via Telegram instead of full EA (simpler, more reliable)

## MT5 EA Structure (MQL5)

See `templates/XAUUSD_Signal_EA.mq5` for a complete EA template that:
- Reads JSON signal files (not pipe-delimited)
- Auto-executes BUY/SELL with SL/TP
- Handles position management (close reverse, avoid duplicates)
- Validates lot size against symbol limits

**Compilation**: Must be done on a Windows PC with MT5 installed. MetaEditor is a GUI app that cannot run on headless VPS.

```mql5
// Key EA logic in OnTick():
// 1. Read signal JSON file
// 2. Check if new signal (compare timestamp)
// 3. Validate SL/TP distances
// 4. Execute trade with retry logic
```

## Signal File Protocol (JSON — Current Standard)

```json
{
  "signal": "BUY",
  "timestamp": "2026-05-27T14:30:00+00:00",
  "price": 3285.50,
  "entry": 3285.50,
  "sl": 3280.00,
  "tp1": 3296.00,
  "tp2": 3310.00,
  "lot_size": 0.05,
  "confidence": "HIGH",
  "trend": "BULLISH",
  "rsi": 35.2,
  "macd": -1.5,
  "macd_histogram": 0.3
}
```

- `signal`: `"BUY"`, `"SELL"`, `"NO SIGNAL"`, or `"WAITING"`
- EA detects new signals by comparing `timestamp` to last executed
- After execution, OWL updates timestamp or sets `signal` to `"NO SIGNAL"`

### Legacy Format (pipe-delimited — deprecated)
```
ACTION|ENTRY_PRICE|STOP_LOSS|TAKE_PROFIT|LOT_SIZE|TIMESTAMP|PROCESSED
BUY|3285.50|3280.00|3296.00|0.05|2026-05-27T14:00:00|0
```

## Python Signal Generator

```python
import json, time, os
from datetime import datetime

SIGNAL_DIR = "/root/.hermes/signals"
SIGNAL_FILE = os.path.join(SIGNAL_DIR, "xauusd.signal")

def write_signal(action, entry, sl, tp, lot, confidence="HIGH"):
    signal = f"{action}|{entry}|{sl}|{tp}|{lot}|{datetime.utcnow().isoformat()}|0"
    with open(SIGNAL_FILE, "w") as f:
        f.write(signal)
    return signal
```

## Data Sources (VPS-compatible)

### Yahoo Finance via `yfinance` (Recommended Primary Source)
- **DO NOT use `XAUUSD=X`** — it's delisted/404 on Yahoo since ~2025
- **Use `GC=F` (Gold Futures)** — works reliably, 30d hourly data available
- GC=F trades ~1.36x XAUUSD spot — for *signal direction* this doesn't matter (same trend)
- For *exact price levels* on your broker: compare GC=F to XAUUSD spot once to get the offset, then apply
- `yfinance` pip install is **very slow on VPS** (~5-6 min) — use `pip install yfinance` in background
- Yahoo Finance API direct (via `urllib`) is **rate-limited** from most VPS IPs — use `yfinance` lib instead
- Test: `python3 -c "import yfinance as yf; df=yf.Ticker('GC=F').history(period='5d',interval='1h'); print(len(df))"`

### Other APIs (often blocked on VPS)
- Frankfurter API — sometimes 301 via Cloudflare
- Twelve Data — free tier available (needs API key)
- Stooq — needs API key for CSV
- metals.dev, currencyapi.com — need API keys
- open.er-api.com — returns error for XAU base

### Paid/free API keys (if needed)
- Twelve Data (1000 calls/day free)
- Alpha Vantage (25 calls/day free)
- Polygon.io (limited free)

## Deployment Checklist

On VPS (this part runs headless):
1. `apt install xvfb wine64`
2. `pip install MetaTrader5` (if using Python direct approach)
3. Set up Wine prefix: `WINEPREFIX=~/.wine /usr/bin/wineboot --init`
4. Download MT5 installer — **but GUI install won't work on headless VPS**
5. Signal bot writes JSON signals to `/root/xauusd-bot/latest_signal.json`

On local Windows PC (user-side):
6. Compile EA `.mq5` → `.ex5` in MetaEditor on their MT5 installation
7. Attach EA to XAUUSD chart
8. Configure signal file path (use shared folder or copy `.ex5` + signals)

## Telegram Signal Fallback

When full EA setup is too complex, use Telegram delivery instead:

```
🔴 SELL XAUUSD @ 3285.50
├── SL: 3290.00 (45 pips)
├── TP1: 3275.00 (105 pips)  
├── TP2: 3265.00 (200 pips)
├── Lot: 0.05
└── Confidence: HIGH
```

See `references/xauusd-strategy.md` for XAUUSD-specific strategy notes.

## Risk Management Rules (Default)

- Risk per trade: 1.5-2% of account
- Max daily loss: 3-5% (stop trading after hitting)
- Max 2 consecutive losses → stop for the day
- SL mandatory on every trade
- Minimum R:R 1:2
- Avoid trading during high-impact news (NFP, CPI, rate decisions)
- Best sessions: London (15:00-18:00 WIB) and NY (20:00-23:00 WIB)
