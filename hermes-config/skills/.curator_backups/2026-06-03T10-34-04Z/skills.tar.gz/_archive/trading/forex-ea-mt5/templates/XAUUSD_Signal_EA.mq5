//+------------------------------------------------------------------+
//|                                         XAUUSD_Signal_EA.mq5     |
//|                         Auto-trade XAUUSD based on signal file   |
//|                         Receives signals from OWL Bot            |
//+------------------------------------------------------------------+
#property copyright "OWL Bot"
#property link      ""
#property version   "1.00"
#property description "XAUUSD Auto-Trade EA - Reads signals from JSON file"

#include <Trade\Trade.mqh>
#include <Trade\PositionInfo.mqh>
#include <Trade\OrderInfo.mqh>

input string   InpSignalFile    = "/root/xauusd-bot/latest_signal.json";
input int      InpMagicNumber   = 777123;
input double   InpDefaultLot    = 0.05;
input bool     InpCloseReverse  = true;
input int      InpMaxRetries    = 3;
input int      InpRetryDelayMs  = 2000;

CTrade         trade;
CPositionInfo  posInfo;
string         _lastTimestamp   = "";
string         _lastDirection   = "";

struct SignalData
{
   string   direction;
   double   entry;
   double   sl;
   double   tp1;
   double   tp2;
   double   lot_size;
   string   confidence;
   string   timestamp;
   bool     valid;
};

string ExtractJSON(string json, string key)
{
   int kp = StringFind(json, key);
   if(kp < 0) return "";
   int cp = StringFind(json, ":", kp + StringLen(key));
   if(cp < 0) return "";
   int s = cp + 1;
   while(s < StringLen(json))
   {
      ushort c = StringGetCharacter(json, s);
      if(c != ' ' && c != '\t' && c != '\n' && c != '\r') break;
      s++;
   }
   if(s >= StringLen(json)) return "";
   if(StringGetCharacter(json, s) == '"')
   {
      int ep = StringFind(json, "\"", s + 1);
      if(ep < 0) return "";
      return StringSubstr(json, s + 1, ep - s - 1);
   }
   int ep2 = s;
   while(ep2 < StringLen(json))
   {
      ushort c = StringGetCharacter(json, ep2);
      if(c == ',' || c == '}' || c == '\n' || c == '\r') break;
      ep2++;
   }
   return StringTrimRight(StringTrimLeft(StringSubstr(json, s, ep2 - s)));
}

bool ParseSignal(string json, SignalData &sig)
{
   sig.valid = false;
   sig.lot_size = InpDefaultLot;
   
   string sDir = ExtractJSON(json, "\"signal\"");
   if(sDir != "BUY" && sDir != "SELL") return false;
   sig.direction = sDir;
   sig.timestamp = ExtractJSON(json, "\"timestamp\"");
   sig.confidence = ExtractJSON(json, "\"confidence\"");
   if(sig.confidence == "") sig.confidence = "MEDIUM";
   
   string pStr = ExtractJSON(json, "\"price\"");
   if(pStr == "") pStr = ExtractJSON(json, "\"entry\"");
   sig.entry = StringToDouble(pStr);
   sig.sl   = StringToDouble(ExtractJSON(json, "\"sl\""));
   sig.tp1  = StringToDouble(ExtractJSON(json, "\"tp1\""));
   sig.tp2  = StringToDouble(ExtractJSON(json, "\"tp2\""));
   string lStr = ExtractJSON(json, "\"lot_size\"");
   if(lStr != "") sig.lot_size = StringToDouble(lStr);
   
   if(sig.entry <= 0) return false;
   sig.valid = true;
   return true;
}

bool ReadSignal(SignalData &sig)
{
   if(!FileIsExist(InpSignalFile)) return false;
   int fh = FileOpen(InpSignalFile, FILE_READ|FILE_TXT);
   if(fh == INVALID_HANDLE) return false;
   string json = "";
   while(!FileIsEnding(fh)) json += FileReadString(fh);
   FileClose(fh);
   if(StringLen(json) < 10) return false;
   return ParseSignal(json, sig);
}

bool HasPos(ENUM_POSITION_TYPE &pt)
{
   for(int i = PositionsTotal()-1; i >= 0; i--)
      if(posInfo.SelectByIndex(i) && posInfo.Magic() == InpMagicNumber)
         { pt = posInfo.PositionType(); return true; }
   return false;
}

void CloseAll()
{
   for(int i = PositionsTotal()-1; i >= 0; i--)
      if(posInfo.SelectByIndex(i) && posInfo.Magic() == InpMagicNumber)
         { trade.PositionClose(posInfo.Ticket()); Sleep(InpRetryDelayMs); }
}

void Execute(SignalData &sig)
{
   if(!sig.valid) return;
   
   double lot = sig.lot_size;
   double minL = SymbolInfoDouble(Symbol(), SYMBOL_VOLUME_MIN);
   double maxL = SymbolInfoDouble(Symbol(), SYMBOL_VOLUME_MAX);
   double step = SymbolInfoDouble(Symbol(), SYMBOL_VOLUME_STEP);
   if(step > 0) lot = MathFloor(lot/step)*step;
   lot = MathMax(minL, MathMin(lot, maxL));
   
   int dg = (int)SymbolInfoInteger(Symbol(), SYMBOL_DIGITS);
   double ask = SymbolInfoDouble(Symbol(), SYMBOL_ASK);
   double bid = SymbolInfoDouble(Symbol(), SYMBOL_BID);
   
   ENUM_POSITION_TYPE et;
   if(HasPos(et))
   {
      if(InpCloseReverse &&
         ((sig.direction=="BUY" && et==POSITION_TYPE_SELL) ||
          (sig.direction=="SELL" && et==POSITION_TYPE_BUY)))
         { CloseAll(); Sleep(InpRetryDelayMs); }
      else { Print("Already in position. Skipping."); return; }
   }
   
   string cmt = "OWL_" + sig.confidence;
   bool ok = false;
   for(int r=0; r<InpMaxRetries; r++)
   {
      if(sig.direction=="BUY")
         ok = trade.Buy(lot, Symbol(), ask,
              NormalizeDouble(sig.sl,dg),
              NormalizeDouble(sig.tp1,dg), cmt);
      else
         ok = trade.Sell(lot, Symbol(), bid,
              NormalizeDouble(sig.sl,dg),
              NormalizeDouble(sig.tp1,dg), cmt);
      
      if(ok) { Print("✅ ",sig.direction," @ ",ask," SL=",sig.sl," TP=",sig.tp1); break; }
      Print("Retry ",r+1,": ",trade.ResultRetcodeDescription());
      Sleep(InpRetryDelayMs);
   }
   if(!ok) { Print("❌ FAILED ",sig.direction); Alert("XAUUSD EA: ",sig.direction," failed"); }
}

int OnInit()
{
   trade.SetExpertMagicNumber(InpMagicNumber);
   trade.SetDeviationInPoints(20);
   trade.SetTypeFilling(ORDER_FILLING_FOK);
   Print("XAUUSD Signal EA | ", InpSignalFile);
   return(INIT_SUCCEEDED);
}

void OnTick()
{
   SignalData sig;
   if(!ReadSignal(sig)) return;
   if(!sig.valid) return;
   if(sig.timestamp == _lastTimestamp && sig.direction == _lastDirection) return;
   
   Print("📡 ",sig.direction," XAUUSD @",sig.entry," SL=",sig.sl," TP=",sig.tp1," Lot=",sig.lot_size);
   Execute(sig);
   _lastTimestamp = sig.timestamp;
   _lastDirection = sig.direction;
}

void OnDeinit(const int reason) { Print("EA stopped."); }
