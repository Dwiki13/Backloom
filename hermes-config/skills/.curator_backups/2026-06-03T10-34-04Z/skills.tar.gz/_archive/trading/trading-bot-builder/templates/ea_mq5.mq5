//+------------------------------------------------------------------+
//| Template: MT5 EA that reads signals from a JSON file              |
//| Place .mq5 in /MQL5/Experts/ and .ex5 in /MQL5/Experts/          |
//| Set SIGNAL_FILE_PATH to a local path readable by MT5              |
//+------------------------------------------------------------------+
#property copyright "Trading Bot"
#property version   "1.00"
#property description "Reads signals from JSON file and executes on MT5"

#include <Trade\Trade.mqh>
#include <Trade\PositionInfo.mqh>

input string   SIGNAL_FILE = "C:\\signals\\latest_signal.json";  // Path must be accessible from MT5
input int      MAGIC       = 777123;
input double   DEF_LOT     = 0.05;
input bool     CLOSE_REV   = true;

CTrade trade;
CPositionInfo posInfo;
string lastTimestamp = "";

string ExtractValue(string json, string key) {
   int kp = StringFind(json, key);
   if(kp < 0) return "";
   int col = StringFind(json, ":", kp + StringLen(key));
   if(col < 0) return "";
   int start = col + 1;
   while(start < StringLen(json) && StringGetCharacter(json, start) == ' ') start++;
   if(start >= StringLen(json)) return "";
   ushort c = StringGetCharacter(json, start);
   if(c == '"') {
      int end = StringFind(json, "\"", start + 1);
      if(end < 0) return "";
      return StringSubstr(json, start + 1, end - start - 1);
   }
   int end = start;
   while(end < StringLen(json)) {
      ushort ch = StringGetCharacter(json, end);
      if(ch == ',' || ch == '}') break;
      end++;
   }
   string v = StringSubstr(json, start, end - start);
   v = StringTrimRight(v); v = StringTrimLeft(v);
   return v;
}

int OnInit() {
   trade.SetExpertMagicNumber(MAGIC);
   trade.SetDeviationInPoints(20);
   trade.SetTypeFilling(ORDER_FILLING_FOK);
   Print("Signal EA initialized. Watching: ", SIGNAL_FILE);
   return INIT_SUCCEEDED;
}

void OnTick() {
   if(!FileIsExist(SIGNAL_FILE)) return;
   
   int fh = FileOpen(SIGNAL_FILE, FILE_READ|FILE_TXT);
   if(fh == INVALID_HANDLE) return;
   
   string json = "";
   while(!FileIsEnding(fh)) json += FileReadString(fh);
   FileClose(fh);
   
   string signal = ExtractValue(json, "\"signal\"");
   if(signal != "BUY" && signal != "SELL") return;
   
   string ts   = ExtractValue(json, "\"timestamp\"");
   double sl   = StringToDouble(ExtractValue(json, "\"sl\""));
   double tp   = StringToDouble(ExtractValue(json, "\"tp1\"));
   double lot  = StringToDouble(ExtractValue(json, "\"lot_size\""));
   if(lot <= 0) lot = DEF_LOT;
   
   // Skip duplicate signals
   if(ts == lastTimestamp) return;
   lastTimestamp = ts;
   
   // Normalize
   int d = (int)SymbolInfoInteger(Symbol(), SYMBOL_DIGITS);
   double ask = SymbolInfoDouble(Symbol(), SYMBOL_ASK);
   double bid = SymbolInfoDouble(Symbol(), SYMBOL_BID);
   sl = NormalizeDouble(sl, d);
   tp = NormalizeDouble(tp, d);
   lot = MathMax(SymbolInfoDouble(Symbol(), SYMBOL_VOLUME_MIN),
         MathMin(lot, SymbolInfoDouble(Symbol(), SYMBOL_VOLUME_MAX)));
   
   // Close opposite positions if needed
   if(CLOSE_REV) {
      for(int i = PositionsTotal()-1; i >= 0; i--) {
         if(posInfo.SelectByIndex(i) && posInfo.Magic() == MAGIC) {
            if((signal=="BUY" && posInfo.PositionType()==POSITION_TYPE_SELL) ||
               (signal=="SELL" && posInfo.PositionType()==POSITION_TYPE_BUY)) {
               trade.PositionClose(posInfo.Ticket());
               Sleep(2000);
            }
         }
      }
   }
   
   // Check no existing position
   for(int i = PositionsTotal()-1; i >= 0; i--) {
      if(posInfo.SelectByIndex(i) && posInfo.Magic()==MAGIC && posInfo.Symbol()==Symbol())
         return; // Already have position
   }
   
   // Execute
   bool ok = false;
   if(signal == "BUY")
      ok = trade.Buy(lot, Symbol(), ask, sl, tp, "OWL_EA");
   else
      ok = trade.Sell(lot, Symbol(), bid, sl, tp, "OWL_EA");
   
   if(ok) Print("✅ Executed ", signal, " lot=", lot, " SL=", sl, " TP=", tp);
   else   Print("❌ Failed ", signal, " error=", GetLastError());
}
