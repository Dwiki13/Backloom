---
name: trading-bot-builder
description: Build algorithmic trading bots — backtest strategies on historical data, compare approaches, and deploy signal bots via Telegram. Covers forex/crypto/commodities with Python. Use when the user wants to create, test, or deploy any kind of trading bot, signal generator, or backtesting system.
---

# Trading Bot Builder

Build algorithmic trading bots: backtest strategies, compare approaches, deploy signal bots.

## When to Use

- User wants to build a trading bot (forex, crypto, commodities, stocks)
- User wants to backtest a trading strategy
- User wants to compare multiple strategies
- User wants to deploy a signal bot (Telegram, webhook, etc.)
- User asks about win rate, profit factor, drawdown, or other trading metrics

## Workflow

### 1. Understand Requirements

Before coding, clarify:
- **Asset**: What instrument? (XAUUSD, EUR/USD, BTC, etc.)
- **Broker**: Which broker? (affects spread, lot size, API availability)
- **Account size**: Starting balance in USD
- **Target**: Monthly/weekly profit goal
- **Risk tolerance**: Max drawdown acceptable
- **Execution**: Auto-trade (EA/API) or signal-only (Telegram/manual)?

### 2. Data Source Selection\n\n**Gold (XAUUSD):**\n- **Historical Analysis**: Use `yfinance` with ticker `GC=F` (Gold Futures) — reliable free source for trends/patterns\n- **Real-time Price**: For execution, prefer real-time spot sources when available\n- GC=F vs Spot Difference: GC=F typically trades at a premium to spot (e.g., $24 difference)\n- **Critical**: For HFM Cent accounts, 1 pip = 10 points, and 1 point = 0.01 price (2 decimal format)\n\n**HFM Cent Specifics:**\n- Spread: Typically 35 points = 3.5 pips\n- Lot 0.01: 10 pips = 1 cent ($0.01)\n- Pip value: 0.01 lot = $0.001 per pip\n\n**Other forex pairs:**\n- `yfinance` with `EURUSD=X`, `GBPUSD=X`, etc.\n- Many forex pairs return 404 from Yahoo; test before committing\n\n**Crypto:**\n- `yfinance` with `BTC-USD`, `ETH-USD`, etc. — generally reliable\n\n**Installation:**\n```bash\npip install yfinance requests\n```\n\n### 3. Strategy Backtesting\n\nAlways backtest before deploying. Use the walk-forward approach:\n\n1. Split data: use past N candles for indicator calculation, evaluate on next candle\n2. Simulate SL/TP hits on future candles (use `high`/`low`, not just `close`)\n3. Include a timeout (e.g., 30 candles max hold) for trades that don't hit SL or TP\n4. Track: win rate, profit factor, net profit, max drawdown, total trades\n\n**Key metrics:**\n- **Win Rate**: % of winning trades (need >50% for 1:2 RR, or >40% for 1:3 RR)\n- **Profit Factor**: Gross profit / Gross loss (need >1.2 for viable strategy)\n- **Max Drawdown**: Largest peak-to-trough decline (keep <30% for safety)\n- **ROI**: (Final - Initial) / Initial * 100\n\n**Common pitfalls:**\n- Don't use `close` price for SL/TP simulation — use `high`/`low` of future candles\n- Fixed SL in pips doesn't adapt to volatility — prefer ATR-based SL\n- Too many confirmation filters = too few trades = unreliable statistics\n- Backtest on at least 100+ trades for statistical significance\n- **Currency-specific**: Always verify pip value and point conversion for your broker/account type\n- **Spread awareness**: Account for spread in effective SL/TP (e.g., 35 point spread adds to SL distance)

### 4. Strategy Comparison

When comparing strategies, run ALL on the SAME dataset with the SAME:
- Initial balance
- Risk per trade (%)
- SL/TP calculation method
- Timeout period

Sort by profit factor first, then max drawdown, then net profit.

### 5. Signal Bot Deployment

**Telegram Bot Setup:**
1. User creates bot via @BotFather on Telegram
2. User gets bot token (format: `123456:ABC-DEF...`)
3. User chats the bot, sends `/start`
4. Get chat ID via @userinfobot or from the chat context
5. Store token and chat_id as environment variables (never hardcode)

**Signal format (recommended):**
```
🟢 BUY XAUUSD 🔥 HIGH
⏰ 2026-05-27 19:00 UTC
━━━━━━━━━━━━━━━
📍 Entry: `3285.50`
🛑 SL: `3280.00` (50 pips)
🎯 TP1: `3295.00` (100 pips)
🎯 TP2: `3305.00` (200 pips)
📦 Lot: `0.05`
⚖️ RR: 1:2 / 1:4
━━━━━━━━━━━━━━━
📊 Trend: BULLISH
📉 RSI: 42.5
📊 MACD: 12.3 (hist: 2.1)
━━━━━━━━━━━━━━━
📝 Reasons:
  • Uptrend (EMA20>EMA50)
  • Near support level
  • RSI in buy zone
━━━━━━━━━━━━━━━
⚠️ Risk: 2% = $3.00
```

### 6. Auto-Trade (Advanced)

**MT5 + Wine on Linux VPS:**
- Wine can run on headless Linux with Xvfb virtual display
- MT5 GUI installer often fails silently — use non-silent mode or extract manually
- EA (.mq5) must be compiled in MetaEditor (requires Wine + MT5 terminal)
- Communication: EA reads signal from local JSON file, bot writes to same file
- **Warning**: This setup is fragile; prefer signal-only + manual execution for small accounts

**Python + MT5 API:**
- `MetaTrader5` Python library can control MT5 terminal directly
- Requires MT5 terminal running somewhere accessible
- More reliable than Wine-based EA compilation

### 7. Risk Management Rules

Always enforce:
- Max 1-2% risk per trade
- Max 2-3 trades per day
- Stop trading after 2 consecutive losses
- Only trade during London/NY session overlap for forex
- Never trade during high-impact news (NFP, CPI, rate decisions)

## Strategy Library

See `references/strategies.md` for detailed strategy implementations and backtest results.
See `references/hfm_cent.md` for HFM Cent account specifications.
See `references/hfm_cent_specifics.md` for detailed HFM Cent trading parameters and calculations.

## Session-Specific Learnings (May 2026)

From recent session building XAUUSD ICT bot for HFM Cent:
- **HFM Cent Specifics**: Confirmed 1 pip = 10 points, 1 point = 0.01 price (2 decimal)
- **Spread Verification**: HFM Cent XAUUSD spread = 35 points (3.5 pips)
- **Optimal Lot Size**: For $10 balance, lot 0.02 provides exactly 2% risk with 100 point SL
- **Data Source Combination**: GC=F for historical analysis (trends/patterns) + Stooq for real-time spot price
- **Strategy Performance**: ICT strategy backtested at 72.2% win rate, PF 9.07 on GC=F data
- **Execution Method**: Signal-only approach recommended for VPS deployment (avoids MT5+Wine complexity)
- **Cron Timing**: 4-hour intervals (0 */4 * * *) sufficient for daily timeframe ICT strategy

## Templates

- `templates/backtest_engine.py` — Generic walk-forward backtest engine
- `templates/signal_bot.py` — Telegram signal bot template
- `templates/ea_mq5.mq5` — MT5 EA template for file-based signal reading
