---
name: automated-trading
description: Build automated forex/crypto trading systems — signal bots, MT5 EAs, Telegram alerts, and Python-based auto-execution. Covers XAUUSD/gold analysis (the most commonly requested pair), HFM/Exness brokers, MT5 via Wine on Linux VPS, yfinance data pipelines, and risk management. Use when the user wants to build, debug, or deploy any trading bot or signal system. Covers both signal-only bots (Telegram delivery) and fully-auto EA-based execution.
triggers:
  - trading bot
  - forex bot
  - auto trade
  - EA MT5
  - signal bot
  - XAUUSD
  - gold trading
  - MetaTrader 5
  - trading signal
  - auto execute trade
---

# Automated Trading Systems

Build and deploy trading bots — from simple Telegram signal delivery to fully-auto MT5 Expert Advisors.

## Architecture Decision: Signal Bot vs Full Auto

**Always discuss both options with the user upfront.** Don't jump to the most complex solution.

### Option A: Signal Bot (Telegram Delivery)
- Python script analyzes data → sends BUY/SELL/SL/TP to Telegram
- User executes manually on their broker platform
- **Pros**: Simple, reliable, no Wine/MT5 needed, works on any VPS
- **Cons**: Manual execution, requires user attention
- **Recommended starting point for new trading systems**

### Option B: Full Auto (MT5 Expert Advisor)
- EA (.mq5) runs inside MT5 terminal, reads signals, auto-executes
- **Pros**: Fully automated, no human delay
- **Cons**: Requires MT5 via Wine on Linux VPS (heavy), GUI dependency, complex setup
- **Only pursue if user explicitly insists** after explaining tradeoffs

## Data Fetching

### Yahoo Finance via yfinance (Primary)
```bash
pip install yfinance --quiet
```
- Use `GC=F` (Gold Futures) as proxy for XAUUSD spot — `XAUUSD=X` is often rate-limited or delisted
- 30 days hourly: `ticker.history(period="30d", interval="1h")`
- Yahoo rate-limits VPS IPs aggressively — use yfinance library, not direct API
- Direct Yahoo endpoints (`query1.finance.yahoo.com`) often blocked/404 from VPS

### Data Pipeline
1. Fetch OHLCV candles via yfinance GC=F 1H (primary, unlimited)
2. Get spot price via gold-api.com /price/XAU/USD (primary, cache 30s, free no auth)
3. Fallback spot: GoldAPI.io (key), Binance PAXG, yfinance last close
4. Run technical analysis
5. Generate signal with direction, entry, SL, TP
6. Save to JSON + send via Telegram

## Technical Analysis (Pure Python)

- **EMA**: 20 & 50 period for trend detection
- **RSI**: 14 period, <30 oversold, >70 overbought
- **MACD**: 12/26/9 for momentum confirmation
- **Support/Resistance**: Round highs/lows to nearest 5, find clusters
- **Signal scoring**: Require 3+ confluence factors before generating signal

## Risk Management Defaults

| Parameter | Conservative | Moderate |
|---|---|---|
| Risk/trade | 1% | 2% |
| SL (XAUUSD) | 50 pips | 30-40 pips |
| TP ratio | 1:2 | 1:1.5 |
| Lot (cent account) | 0.01-0.03 | 0.03-0.05 |
| Max daily loss | 2 trades | 3 trades |

**⚠️ Pip Math Warning:** For HFM/Exness Cent accounts, KII verified: **lot 0.01 → 10 pips = 1 cent** (1 pip = 0.1 cent). The correct formula is `risk_cent = (lot / 0.01) * sl_pips * 0.1`. See `forex-trading` skill → `references/cent-account-math.md` for full detail.

## Broker Selection

KII's active broker is **HFM Cent** ($10 account). See `forex-trading` skill for full broker-specific math.

## Modal Guidelines

| Target/Month | Recommended Min Modal | Lot | Notes |
|---|---|---|---|
| $25 | $10+ (1000c+) | 0.01 | Cent micro account — fixed lot, ~1c risk/trade |
| $50 | $500 | 0.05-0.10 | More comfortable |
| $100+ | $1000+ | 0.10 | Proper scaling possible |

**Note:** KII actively trades XAUUSD on HFM Cent with $10 (1000c) using lot 0.01. At this size, risk is ~1c per trade (10 pip SL). This is viable for learning and small consistent gains.

## Wine + MT5 on Linux VPS

**Only if user explicitly wants full auto-execute.**

```bash
# Ubuntu/Debian setup
apt-get install -y xvfb wine64

# Start virtual display (background!)
Xvfb :99 -screen 0 1024x768x24 -ac &

# Initialize Wine
export DISPLAY=:99 WINEARCH=win64 WINEPREFIX=/root/.wine
/usr/bin/wineboot --init  # NOT wine64 — use /usr/bin/wine
```

### Key Pitfalls
- Wine binary is `/usr/bin/wine` on Ubuntu (not `wine64` command)
- Xvfb MUST run before any Wine command — background it first
- **MT5 GUI installer fails on headless VPS** — `wine mt5setup.exe /silent` exits 0 but doesn't install. `nodrv_CreateWindow` / `kernel32.dll` errors = Wine can't render GUI. No workaround short of full GPU/driver passthrough.
- **MetaEditor cannot compile EAs on headless VPS** — it's a Windows GUI IDE. Compile `.mq5` → `.ex5` on a local Windows PC, then copy the `.ex5` file to the Wine prefix.
- The practical alternative: **signal bot + user compiles EA locally**. Write EA source on VPS, send to user, they compile on their Windows PC running MT5.
- pip installs (`yfinance`, `MetaTrader5` Py library) can be very slow on VPS (~5+ min) — use background process
- NEVER handle user's broker credentials directly
- MT5 terminal must stay running 24/7

### Wine + Xvfb Startup Sequence (Tested)
```bash
# 1. Start Xvfb (background, persistent)
Xvfb :99 -screen 0 1024x768x24 -ac +extension GLX +render -noreset &
sleep 2

# 2. Initialize Wine prefix
export DISPLAY=:99 WINEARCH=win64 WINEPREFIX=/root/.wine
/usr/bin/wineboot --init   # Ignore "nodrv_CreateWindow" errors — normal on headless

# 3. Test
/usr/bin/wine cmd /c "echo hello"   # Should print "hello"
```
Errors like `nodrv_CreateWindow`, `RpcSs`, `systray` are **normal** on headless — Wine still works for CLI operations.

## MT5 Signal File Pattern

Standard handoff between Python analyzer and MT5 EA:

```python
signal = {
    "direction": "BUY",     # BUY, SELL, NONE
    "entry": 3285.50,
    "sl": 3280.00,
    "tp1": 3295.00,
    "tp2": 3305.00,
    "lot_size": 0.05,
    "confidence": "HIGH",
    "timestamp": "2025-01-15T14:30:00Z"
}
with open("/path/to/signal.json", "w") as f:
    json.dump(signal, f)
```

EA reads this file on each tick; executes on new signal.

## Telegram Delivery via send_tg() in Python (Preferred for Bot Scripts)

When the bot itself sends to Telegram via Python `requests`, use this pattern:

```python
def send_tg(msg):
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID: return False
    try:
        chat_id = TELEGRAM_CHAT_ID
        params = {"chat_id": chat_id, "text": msg}
        # For topic/thread delivery, parse "chat_id:thread_id" format
        if ":" in str(chat_id):
            parts = str(chat_id).split(":", 1)
            params["chat_id"] = parts[0]
            params["message_thread_id"] = parts[1]  # MUST be separate param!
        r = requests.post(
            f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage",
            json=params, timeout=15)
        return r.status_code == 200
    except Exception as e:
        log(f"Telegram error: {e}"); return False
```

**⚠️ CRITICAL**: `message_thread_id` MUST be a separate JSON param. Do NOT embed it in `chat_id` (e.g., `chat_id="-100xxx:334"`) — Telegram API will treat it as a regular chat and send to the main topic/general chat instead.

**Loading bot token from .env:**
```python
# Load .env if available (token in env file doesn't auto-load into os.environ)
_env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
if os.path.exists(_env_path):
    with open(_env_path) as _f:
        for _line in _f:
            _line = _line.strip()
            if _line and not _line.startswith("#") and "=" in _line:
                _k, _v = _line.split("=", 1)
                _k = _k.strip(); _v = _v.strip().strip('"')
                if _k == "TELEGRAM_BOT_TOKEN" and not TELEGRAM_BOT_TOKEN:
                    TELEGRAM_BOT_TOKEN = _v
                elif _k == "TELEGRAM_CHAT_ID" and not TELEGRAM_CHAT_ID:
                    TELEGRAM_CHAT_ID = _v
```

**Bot handles delivery = cron should NOT double-deliver:**
- When the bot script calls `send_tg()` internally, the cron job should NOT also deliver output via `send_message`
- Use `deliver="local"` in cron config — the bot's own `send_tg()` handles Telegram delivery
- The cron agent just needs to run the script and return the output locally

## Journal Format (Per-Signal with Multi-Position)

Journal tracks SIGNAL BOT only (not manual trades). Balance reflects real HFM balance (set manually by user).

**Schema:**
```json
{
  "account": "HFM Cent",
  "currency": "cent",
  "start_balance_cent": 1447.23,
  "balance_cent": <real HFM balance>,
  "signals": [
    {
      "signal_id": 1,
      "timestamp": "ISO8601",
      "strategy": "London Breakout",
      "direction": "BUY",
      "positions": [
        {"pos": 1, "entry": 4537.78, "sl": 4525.60, "lot": 0.05, "result": "W", "pnl": 64.10, "note": "TP1 hit"}
      ],
      "signal_pnl": 64.10,
      "status": "CLOSED"
    }
  ],
  "stats": {
    "total_signals": 4,
    "wins": 1,
    "losses": 3,
    "be": 0,
    "win_rate": 25,
    "pnl_cent": -149.55
  }
}
```

**Key rules:**
- 1 signal = 1 journal entry, regardless of how many positions user takes
- `positions[]` array holds each individual position within that signal
- Stats (`wins`/`losses`/`be`) are counted PER SIGNAL, not per position
- `win_rate` = wins / total_signals * 100
- `balance_cent` = real HFM balance (includes manual trades), NOT start_balance + bot_pnl
- `pnl_cent` in stats = sum of all signal PNL (bot only)
- Bot config `C["balance_cent"]` must be updated manually when user reports new balance
- When user reports results, format: "Signal #X: [W/L/BE] [lot] Entry [price] [TP1/SL/exit] [pnl]"

**Bug fix (May 2026):** Old journal format used `st["total"]` key. New format uses `st["total_signals"]`. Bot's `fmt_journal_summary()` MUST use `st["total_signals"]` not `st["total"]`.

## Market Structure Filter (Trend-Aware Signals)

Add trend analysis to avoid trading against the market:

```python
def analyze_market_structure(candles, lookback=20):
    """Detect trend from swing points. Returns 'uptrend' (HH+HL), 'downtrend' (LH+LL), or 'ranging'."""
    # Find swing highs/lows (higher-high + higher-low = uptrend, etc.)

def filter_by_trend(direction, structure):
    """Block SELL in uptrend, BUY in downtrend."""
    if structure == 'uptrend' and direction == 'SELL': return False
    if structure == 'downtrend' and direction == 'BUY': return False
    return True

def get_loss_review(candles):
    """After 2+ consecutive losses against trend, generate review + correction."""
    # Check journal for recent losses, cross-reference with market structure
    # Returns review string like: "LOSS REVIEW: Market UPTrend (HH+HL) | SELL loss 4x | Fokus BUY dalam uptrend"
```

**Integration in main():**
```python
# After each strategy generates a signal:
if sig:
    structure, _, _ = analyze_market_structure(candles)
    if not filter_by_trend(sig['direction'], structure):
        log(f"Blocked {sig['direction']} against {structure} trend")
        sig = None  # Let next strategy try

# After format_msg():
loss_review = get_loss_review(candles)
if loss_review:
    msg = msg + "\n\n" + loss_review
```

**Typical output in signal message:**
```
⚠️ LOSS REVIEW: Market UPTrend (HH+HL) | SELL loss 4x | Fokus BUY dalam uptrend
```

## EA Development (.mq5)

See `forex-ea-mt5` skill for full EA development guide and the `XAUUSD_Signal_EA.mq5` template.

Key constraints on Linux VPS:
- MetaEditor is a Windows GUI app → **cannot compile `.mq5` on headless VPS**
- Solution: Develop source on VPS, send to user, they compile on their Windows MT5
- Copy compiled `.ex5` back to Wine prefix `MQL5/Experts/` directory

## XAUUSD Session Strategies (KII's Active Bot)

As of May 2028, KII runs a multi-session breakout bot with 3 strategies:
- **London Breakout** (15-22 WIB): Opening range breakout
- **NY Open Momentum** (20-23 WIB): First NY candle direction
- **Asian Range Breakout** (12-21 WIB): Asia range → London breakout

Cron schedule: `0 15,16,17,18,19,20,21,22,23 * * *` (WIB) = 9x/day covering London + NY sessions
Bot file: `/root/xauusd-bot/xauusd_multi_session.py`
Journal: `/root/xauusd-bot/trading_journal.json`

See `forex-trading` skill for full strategy details, lot sizing, and output format.

## XAUUSD Specifics

- Gold moves ~1000-2000 pips/day during active sessions
- Pip convention on HFM Cent 2-decimal: **100 points = 10 pips**
- Best sessions: London (15:00-18:00 WIB) & NY (20:00-23:00 WIB)
- Spread on HFM Cent: ~35 points (3.5 pips)
- GC=F futures ≈ XAUUSD spot (price varies, check current rate)
- Retail brokers (HFM, Exness) do NOT provide trading APIs — need MT5+EA for auto
- **Signal format: USD prices for entry/SL/TP, cent for risk/PnL/balance** (KII preference)
