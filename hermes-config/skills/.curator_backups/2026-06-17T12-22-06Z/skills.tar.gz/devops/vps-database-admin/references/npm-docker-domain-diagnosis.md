# NPM + Docker Domain Diagnosis Sequence

When a domain pointing to a VPS with Nginx Proxy Manager + Docker containers isn't working, follow this exact diagnostic order:

## 1. DNS Resolution Check
```bash
# From client machine (PowerShell):
nslookup your-domain.com
# or
dig your-domain.com
```
- **NXDOMAIN** → DNS record missing. Add A record at your DNS provider.
- **Resolves to wrong IP** → Check if Cloudflare proxy (orange) is enabled — that gives Cloudflare IPs, not your VPS IP. Use DNS-only (gray) for self-hosted backends.

### ⚠️ Indonesian ISP DNS Intercept
If `nslookup` returns NXDOMAIN on **all** DNS servers (Google 8.8.8.8, Cloudflare 1.1.1.1, OpenDNS) simultaneously — the record may still exist. Some Indonesian ISPs (IndiHome, etc.) hijack DNS and return NXDOMAIN for any domain they don't recognize, regardless of the authoritative NS.
- **Confirm**: Use a VPN or check from a different country. If the domain resolves there, it's ISP intercept.
- **Quick fix**: hosts file override (see section "Quick Local Test" below) — this bypasses ISP DNS entirely.

## 2. NPM Config Check
```bash
# From VPS — list proxy host configs:
docker exec npm_npm_1 find /data/nginx/proxy_host -name "*.conf" -exec echo "=== {} ===" \; -exec cat {} \;
n```
Verify:
- `server_name` matches the domain exactly
- `$server` is a **container name** (not `localhost`) from a Docker network shared with NPM
- `$port` matches the container's internal port (not the host-mapped port)
- SSL cert path exists and is valid

## 3. Docker Network Topology
```bash
# Check which networks each container is on:
docker inspect <container> --format '{{json .NetworkSettings.Networks}}' | python3 -m json.tool
```
- NPM and the API container **must share a Docker network** for container name resolution to work.
- If they're on different networks, either connect the container to NPM's network or use the IP from the shared network.
- `localhost` from a container = that container itself, NOT the host VPS.

## 4. Container Health
```bash
docker ps -a --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"
docker logs <container> --tail 30
```
- Verify container is `Up` and the expected port is mapped.
- Check logs for errors (connection refused, upstream not found, etc.).

## 5. NPM Error Logs
```bash
docker exec npm_npm_1 tail -20 /data/logs/proxy-host-<ID>_error.log
```
Common errors:
- `localhost could not be resolved` → NPM config has `localhost` instead of container name
- `connect() failed (111: Connection refused)` → Container name resolves but port is wrong or container is down
- `502 Bad Gateway` → NPM can't reach the upstream (wrong container name, wrong port, or container down)

## 6. SSL Certificate
```bash
docker exec npm_npm_1 openssl x509 -in /etc/letsencrypt/live/npm-<ID>/fullchain.pem -noout -dates -subject
```
- Check cert is not expired
- Check `Subject` matches the domain name exactly

## 7. End-to-End Test
```bash
# From client machine:
curl.exe -I https://your-domain.com    # PowerShell
curl -I https://your-domain.com       # Linux/Mac
```
- **403/401** → API is working (auth required)
- **502** → NPM can't reach upstream
- **000/timeout** → DNS or firewall issue

## Quick Local Test (hosts File Override)
When DNS hasn't propagated yet but you need to test from a specific machine:
- **Windows**: Add `<VPS_IP> your.domain.id` to `C:\\Windows\\System32\\drivers\\etc\\hosts` (open Notepad as Admin)
- **Linux/Mac**: Add `<VPS_IP> your.domain.id` to `/etc/hosts` (`sudo nano /etc/hosts`)
- This bypasses DNS entirely — useful for development while waiting for Cloudflare propagation
- Only works on the machine where it's added; does NOT affect other devices (phones, other PCs)
- Remove the line when DNS is live to avoid stale entries

## Direct Config Edit (Without NPM UI)

When the NPM web UI is inaccessible or you need a fast fix, edit the proxy host config directly via sed:

```bash
# List proxy host configs to find the file number:
docker exec npm_npm_1 find /data/nginx/proxy_host -name "*.conf" -exec echo {} \;

# Edit the config (e.g., change port from 8002 to 8000):
docker exec npm_npm_1 sed -i 's/set $port           8002;/set $port           8000;/' /data/nginx/proxy_host/3.conf

# Validate and reload:
docker exec npm_npm_1 nginx -t
docker exec npm_npm_1 nginx -s reload
```

Config files are in `/data/nginx/proxy_host/` (**underscore**, not hyphen). The `server_name`, `$server` (container name), and `$port` (container-internal port) are the three values most commonly wrong.

## PowerShell curl Gotcha

PowerShell aliases `curl` to `Invoke-WebRequest` — different syntax, different flags. When instructing Windows users to test from PowerShell:
- Use `curl.exe` (not `curl`) for Linux-compatible syntax: `curl.exe -I https://domain.com`
- Or use `Invoke-WebRequest -Uri "https://domain.com" -UseBasicParsing | Select-Object StatusCode`
- `nslookup` works the same in both PowerShell and cmd
- After DNS changes, run `ipconfig /flushdns` to clear the local DNS cache
- To query a specific DNS server: `nslookup domain.com 1.1.1.1` (Cloudflare) or `nslookup domain.com 8.8.8.8` (Google)

## Key Pitfalls
- **Cloudflare Proxied vs DNS-only**: For self-hosted backends, use DNS-only (gray cloud). Proxied adds Cloudflare IPs and can cause 502 if NPM doesn't recognize the domain.
- **Container name vs localhost**: NPM is a Docker container. `localhost` inside NPM = NPM itself. Always use the API container name.
- **Port mapping**: Docker maps `host_port:container_port`. NPM needs the **container port** (the one the app listens on inside the container), not the host-mapped port. E.g., if `docker run -p 8002:8000`, use port `8000` in NPM's forward config.
- **Domain mismatch**: The domain in Cloudflare DNS must exactly match the `server_name` in NPM's proxy host config.

## Quick Local Test (hosts File Override)
When DNS hasn't propagated yet but you need to test from a specific machine:
- **Windows**: Add `<VPS_IP> your.domain.id` to `C:\\Windows\\System32\\drivers\\etc\\hosts` (open Notepad as Admin)
- **Linux/Mac**: Add `<VPS_IP> your.domain.id` to `/etc/hosts` (`sudo nano /etc/hosts`)
- This bypasses DNS entirely — useful for development while waiting for Cloudflare propagation
- Only works on the machine where it's added; does NOT affect other devices (phones, other PCs)
- Remove the line when DNS is live to avoid stale entries

## Direct Config Edit (Without NPM UI)

When the NPM web UI is inaccessible or you need a fast fix, edit the proxy host config directly via sed:

```bash
# List proxy host configs to find the file number:
docker exec npm_npm_1 find /data/nginx/proxy_host -name "*.conf" -exec echo {} \;

# Edit the config (e.g., change port from 8002 to 8000):
docker exec npm_npm_1 sed -i 's/set $port           8002;/set $port           8000;/' /data/nginx/proxy_host/3.conf

# Validate and reload:
docker exec npm_npm_1 nginx -t
docker exec npm_npm_1 nginx -s reload
```

Config files are in `/data/nginx/proxy_host/` (**underscore**, not hyphen). The `server_name`, `$server` (container name), and `$port` (container-internal port) are the three values most commonly wrong.

## PowerShell curl Gotcha

PowerShell aliases `curl` to `Invoke-WebRequest` — different syntax, different flags. When instructing Windows users to test from PowerShell:
- Use `curl.exe` (not `curl`) for Linux-compatible syntax: `curl.exe -I https://domain.com`
- Or use `Invoke-WebRequest -Uri "https://domain.com" -UseBasicParsing | Select-Object StatusCode`
- `nslookup` works the same in both PowerShell and cmd
- After DNS changes, run `ipconfig /flushdns` to clear the local DNS cache
- To query a specific DNS server: `nslookup domain.com 1.1.1.1` (Cloudflare) or `nslookup domain.com 8.8.8.8` (Google)
