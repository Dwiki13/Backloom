---
name: google-ads-analysis
description: Analyze Google Ads campaign performance from exported CSV data. Extract actionable insights on keywords, demographics, devices, time patterns, and budget optimization. Trigger when user shares Google Ads CSV exports (ZIP or individual files), asks for campaign analysis, ROI review, or optimization recommendations. Also trigger when the user wants business financial tracking (buku besar, GAP analysis, weekly reports) for their advertising-driven business.
---

# Google Ads Campaign Analysis + Business Financial Tracking

Analyze Google Ads performance data exported as CSV files, and optionally maintain business financial records (buku besar) for advertising-driven businesses.

## Workflow

### 1. Receive & Extract Data

User usually exports as ZIP from Google Ads → Reports → Download → CSV.

```bash
unzip -o "file.zip" -d /tmp/google_ads/
```

**⚠️ CSV Encoding:** Google Ads billing CSV exports are often **UTF-16 LE with BOM**. If `read_file` reports "Binary file", decode with:
```bash
python3 -c "
with open('file.csv', 'rb') as f:
    raw = f.read()
text = raw.decode('utf-16-le', errors='replace')
print(text)
"
```

Typical CSV files inside:
- `Time_series*.csv` — daily clicks, impressions, CPC, cost
- `Devices*.csv` — cost/clicks/impressions by device
- `Networks*.csv` — Google Search vs Search Partners
- `Demographics(Age*.csv` — age range impressions
- `Demographics(Gender*.csv` — gender split
- `Demographics(Gender_Age*.csv` — gender × age cross-tab
- `Day_&_hour*.csv` — day-of-week and hourly patterns
- `Search_keywords*.csv` — keyword, match type, status, cost, clicks, CTR
- `Searches(Search*.csv` — search terms with cost/clicks/conversions
- `Searches(Word*.csv` — word-level breakdown
- `Billing activity report.csv` — payment/spend/credit history (UTF-16 encoded)

### 2. Read & Analyze

Read ALL CSV files. Use Python for aggregation if needed.

Key metrics to compute:
- **Total spend, clicks, impressions, avg CPC, CTR**
- **Cost per day** — identify high/low days
- **Top keywords by cost** — which eat the most budget
- **CTR by keyword** — high CTR = relevant, low CTR = waste
- **Match type performance** — Broad vs Phrase vs Exact
- **Device split** — mobile vs desktop vs tablet
- **Network split** — Google Search vs Search Partners
- **Demographics** — age, gender, geo
- **Time patterns** — best days/hours
- **Conversions** — if tracking is set up
- **Payment flow** — deposits, running balance, VAT/fees (from billing CSVs)

### 3. Identify Problems

Common issues to flag:
- **Zero conversions** — conversion tracking not installed
- **Broad match bleeding budget** — irrelevant queries from broad match
- **No negative keywords** — informational queries wasting spend
- **High CPC keywords with low CTR** — poor relevance
- **Mobile-heavy traffic with zero conversions** — landing page issues
- **Keywords with "Removed" status** — still showing historical spend data
- **Search Partners underperforming** — low-quality traffic
- **Weekend CPC spikes** — bid adjustment needed for weekend days

### 4. Deliver Analysis Report

**⚠️ Telegram Formatting:** Telegram does NOT support markdown tables. Use bullet lists, emoji headers, and `key: value` pairs instead.

Structure the output:

```
📊 RINGKASAN — [Domain] (Date Range)

⏱️ TIME SERIES (Harian)
• Hari → Klik → Spend → CPC
• e.g. Sen 6 Jun → 9 klik → Rp 51.429 → Rp 5.714/klik

🔍 KEYWORD ANALYSIS
• keyword (match type, status): Rp X spend, X klik, X% CTR
• ⚠️ Removed keywords with historical spend

📱 DEVICES
• Mobile: Rp X, X klik
• Desktop: Rp X, X klik

🌐 NETWORKS
• Google Search: Rp X, X klik, Rp X CPC
• Search Partners: Rp X, X klik, Rp X CPC

👥 DEMOGRAPHICS
• Gender: Male X% / Female X%
• Top age: 25-34 (X%)

⏰ WAKTU TERBAIK
• Best day: Thursday (avg X klik)
• Best hour: 10:00-12:00

💳 PAYMENT FLOW (from billing CSVs)
• Total deposits: Rp X
• Total spend: Rp X
• VAT/fees: Rp X
• Remaining balance: Rp X

🎯 INSIGHT & REKOMENDASI

✅ YANG UDAH BAGUS
• Point 1
• Point 2

⚠️ MASALAH BESAR
• Problem 1
• Problem 2

🔧 REKOMENDASI ACTION
1. 🔴 High — Action → Expected impact
2. 🟡 Medium — Action → Expected impact
3. 🟢 Long-term — Action → Expected impact
```

**Style preferences (Indonesian market):**
- Indonesian/English mix (casual, direct)
- Format IDR with thousand separators: `Rp 656.580` not `656580`
- Use emoji headers for scanability
- Keep it actionable — always end with what to DO
- Concise over verbose — no fluff
- No markdown tables (Telegram doesn't support them)

### 5. Provide Actionable Steps

Always give COMPLETE, specific steps — not vague instructions. Include:
- Exact menu paths in Google Ads UI
- Exact text to paste (e.g., negative keywords list)
- Code snippets if relevant (e.g., conversion tracking tags)
- Priority order (what to do first)

## Key Indonesian Market Notes

- Budget often in IDR — format as Rp with thousand separators
- Common negative keywords for service businesses: `gratis`, `tutorial`, `cara bikin`, `cara membuat`, `free`, `diy`, `sendiri`
- High-intent keywords often include: `jasa`, `profesional`, `pembuatan`, `buat`
- Informational queries to exclude: `cara`, `tutorial`, `gratis`, `membuat sendiri`
- WhatsApp is primary conversion channel for Indonesian service businesses

## Conversion Tracking Setup (When Missing)

If conversions = 0 across all data, guide user through:

1. **Google Ads** → Tools & Settings → Measurements → Conversions → New conversion action
2. **Google Tag Manager** → New Tag → Google Ads Conversion Tracking
3. **Website** → Install GTM container code + conversion event triggers (button clicks, form submits)

For Next.js sites: add GTM script to `_app.tsx` or `_document.tsx`.
For WordPress: use Google Site Kit plugin.
For static HTML sites: add GTM script in `<head>` and event listeners on buttons/forms.

### Static HTML Sites (No Framework)

When the site is plain HTML/JS (not Next.js/React), conversion tracking is simpler:

1. Add GTM container snippet in `<head>` (before `</head>`)
2. Add `gtag('event', 'conversion', ...)` on button click / form submit
3. If GA4 is already loaded via `gtag('config', 'G-XXXXX')`, just add event listeners on key CTAs
4. Common CTA triggers: WhatsApp button click, contact form submit, phone number click

### When User Says "You Do It" (Akses ke VPS)

If the user wants you to directly modify the website on their VPS:
- Find the site root: `find /var/www -maxdepth 2 -name "index.html"`
- Check existing tags: `grep -n "gtag\|google\|GA4\|AW-\|googletagmanager" /var/www/domain/html/index.html`
- Check JS files for existing event tracking: `grep -n "gtag\|generate_lead\|conversion" /var/www/domain/html/main.js`
- Edit files directly on VPS, then reload nginx: `sudo systemctl reload nginx`
- Always backup before editing: `cp index.html index.html.bak.$(date +%s)`

### Getting Conversion ID from Google Ads

To get the Conversion ID (`AW-XXXXXXXXX`) and Conversion Label:
1. Google Ads → Tools & Settings → Measurements → Conversions → + New conversion action
2. Website → Category: Submit lead form → Create and continue
3. "Install the tag yourself" → copy Conversion ID and Label
4. User must do this themselves — agent cannot create conversion actions on their behalf

## Setting Conversion Values

Newly created conversions often have default values of 1.00 or 7.00 — these are NOT real values. Always check and update:

1. Google Ads → Tools & Settings → Measurements → Conversions
2. Click the conversion name → Edit → set **Value** to realistic amount
3. For service businesses: set lead form = lowest package price (e.g., 1,500,000), outbound click = estimated lead value (e.g., 500,000)

**Note:** If the "Value" field is not visible in the UI, the account may use a different version. Try clicking the conversion name to see its detail page, or check if there's a "Settings" tab within the conversion action.

Also check **Conversion Window** — default is often 90 days. For service businesses, 30 days is more realistic to avoid double-counting.

## Setting Up Negative Keywords

Always provide the COMPLETE list ready to paste. Common Indonesian service business negatives:

```
gratis, tutorial, cara bikin, cara membuat, free, diy, sendiri,
000webhost, jimdo, carrd, netlify, wix, sites google,
template gratis, how to, membuat website gratis, cara bikin website gratis
```

Apply at campaign level: Tools & Settings → Bulk Actions → Add negative keywords.

## Pausing Broad Match Keywords

Broad match bleeds budget on irrelevant queries. Always recommend pausing:
1. Keywords tab → filter by Broad match → select all → Edit → Pause
2. Keep Phrase match and Exact match only

## Pitfalls

### Google Ads UI Varies by Account Type

Menu paths differ across Google Ads account versions. "Conversions" might be under "Measurements", "Tools & Settings", or accessible only via direct URL.

**Fix:** If user can't find a menu, provide the direct URL:
- Conversions: `https://ads.google.com/aw/conversions`
- Also try: `https://ads.google.com/aw/measurement`

Ask user to screenshot their Tools & Settings page if documented paths don't match.

### Conversion Value = Default (1.00 / 7.00)

Newly created conversions show values like 1.00 or 7.00 — these are Google defaults, not real business values. ROAS and CPA optimization will be meaningless until corrected.

**Fix:** Always check conversion values in the data. If suspiciously small (1, 7, 0), guide user to set realistic values based on their service pricing.

### User Can't Find "Conversion" Menu

Some Google Ads accounts don't show "Conversion" under Tools & Settings at all. This happens with newer account types or accounts that haven't completed initial setup.

**Fix:** User must first create a conversion action: Tools & Settings → Measurements → Conversions → + New conversion action. If "Measurements" doesn't exist, the account may need to complete the initial setup wizard first.

### ⚠️ Always Confirm CPC Max Setting

Before doing any cost projection or scaling analysis, **always confirm the user's CPC max setting**. Do NOT assume Rp 7,000 or any other default. For DevLokal ID, CPC max = **Rp 5,000**. Using wrong CPC will invalidate all downstream projections (cost, ROI, break-even, scaling roadmap).

### Budget Scaling Analysis (Standard Workflow)

When user asks for scaling/budget analysis, always include:
1. **Scaling table** — 1x to 5x with clicks, spend, estimated deals, revenue, ROAS
2. **Break-even analysis** — B/E click-to-deal rate, deals needed per level
3. **CPC sensitivity** — Show profit/ROI impact if CPC rises 10-30% at target scale
4. **Phased roadmap** — Phase 1 (2x), Phase 2 (3x), Phase 3 (4-5x) with timeline
5. **Key risks** — CPC inflation, conversion rate dilution, need for conversion tracking before scale

Use the DevLokal ID case study (`references/case-study-devlokal-id.md`) as a template for this analysis.

### ⚠️ Don't Recommend Scaling Before First Conversion

When a campaign has **zero conversions/deals**, scaling analysis is **premature and potentially harmful**. Instead:

1. **Acknowledge the elephant**: "122 clicks, 0 closing = funnel problem, not volume problem"
2. **Diagnose the funnel**: Clicks → Landing Page → WA Click → Lead → Deal → Close. Identify where the drop-off is.
3. **Recommend waiting**: "10 days is too early for statistical significance. Review after 30 days."
4. **Focus on quick wins**: Dayparting, bid adjustments, negative keywords — improve efficiency without increasing budget
5. **Set a review date**: Schedule follow-up analysis (e.g., 1 month) rather than making premature scaling decisions

**Red flags that scaling is premature:**
- Zero conversions/deals so far
- Less than 30 days of data
- No conversion tracking installed
- Landing page not yet audited/optimized

**When scaling IS appropriate:** User explicitly asks for it AND has at least some conversion data to baseline from. Even then, recommend phased approach (2x → measure → 3x → measure).

### Alternative Acquisition: Direct WA Outreach

When Google Ads isn't converting yet, suggest **direct WhatsApp outreach** to UMKM as a parallel acquisition channel:

**Approach:**
- Target UMKM in specific areas (e.g., Jabodetabek) that lack websites or have poor ones
- Use soft, personalized pitch — mention their business by name, ask before pitching
- Script template:
  ```
  Halo [Nama], perkenalkan Dwiki dari DevLokal.
  Saya lihat bisnis [Nama Bisnis] di [sumber — GoogleMaps/IG].
  Mau tanya — saat ini sudah punya website untuk bisnisnya?
  Kalau belum, kami bikin website mulai 1.5jt,
  bisa dibantu buatkan. Ga ada paksaan,
  kalau tertarik bisa saya kirim contoh portfolio.
  ```

**⚠️ Google Maps Scraping Warning:**
- Google Maps scraping is **unreliable** (bot detection, limited results without login, ToS violation)
- Headless browser scraping often fails or gets blocked, even with Playwright/Selenium
- Google Places API requires enabling the API in GCP console (existing API keys may not have access)
- **Better alternatives for building target list:**
  - Manual search on Google Maps (1-2 hours for 100 targets — most reliable)
  - Buy UMKM database (Rp 50-200K per 1000 data on Tokopedia/Google)
  - Scrape Instagram (UMKM often have WA in bio, more accessible via hashtag search)
  - Google Ads lead form extension (most scalable long-term)

**Outreach volume guidance:**
- Manual personalized: 10-20 messages/day
- Cold pitch response rate: ~5-10%
- Closing rate: ~2-3% of respondents
- **This is NOT scalable** — use as stopgap while optimizing Google Ads funnel

### CSV Encoding: UTF-16 LE

Google Ads billing/activity CSV exports are often encoded as **UTF-16 LE with BOM**, not UTF-8. The `read_file` tool will report "Binary file" for these.

**Fix:** Decode via terminal:
```bash
python3 -c "
with open('file.csv', 'rb') as f:
    raw = f.read()
text = raw.decode('utf-16-le', errors='replace')
print(text)
"
```

### Weekly Recurring Reports via Cron

When the user wants weekly automated reports:
1. Create a cron job with `schedule: "0 10 * * 0"` (Sunday 10:00 WIB)
2. Use `deliver: "local"` + `send_message` in the prompt for clean Telegram delivery
3. Load the `google-ads-analysis` skill via `skills: ["google-ads-analysis"]`
4. The prompt should instruct the LLM to: find latest CSVs → analyze → save report → send to Telegram
5. Save reports to a consistent path: `/root/projects/<business>/reports/google-ads-weekly-YYYY-MM-DD.md`

## Business Financial Tracking (Accountant Role)

When the user assigns an "accountant" or "bookkeeper" role for their business:

### Buku Besar (Ledger) Maintenance
- Create/maintain a monthly buku besar at `/root/projects/<business>/reports/buku-besar-YYYY-MM.md`
- Use the template at `templates/buku-besar-template.md`
- Update whenever the user reports income or expenses in natural language:
  - "Bayar VPS Rp 350rb" → add to pengeluaran
  - "Dapet project landing page dibayar Rp 1.5jt" → add to pemasukan
- Track: Saldo Awal, Pengeluaran (Ads, PPN, VPS, etc.), Pemasukan, GAP analysis

### Weekly Report via Cron
- Set up cron job: `schedule: "0 10 * * 0"` (Sunday 10:00 WIB)
- `deliver: "local"` + `send_message` in prompt for clean Telegram delivery
- Report covers: ad spend summary, cash flow, GAP, actionable recommendations
- Save to `/root/projects/<business>/reports/google-ads-weekly-YYYY-MM-DD.md`

### Indonesian Service Business Pricing Benchmarks
- Landing page: Rp 1.000.000 - 2.500.000
- Company profile: Rp 1.500.000 - 3.000.000
- Toko online: Rp 2.000.000 - 5.000.000
- Custom web app: Rp 3.000.000+
- Use these as reference when setting conversion values in Google Ads

## References

- `references/indonesian-market-keywords.md` — Common keyword patterns and negative keyword lists for Indonesian service businesses
- `references/vps-static-site-patterns.md` — Patterns for analyzing and modifying static HTML sites on VPS (Nginx deployments)
- `references/case-study-devlokal-id.md` — Full case study: DevLokal ID Google Ads analysis, billing data, business financial tracking setup, and lessons learned
- `references/scaling-analysis-template.py` — Reusable Python script for scaling analysis (break-even, CPC sensitivity, phased roadmap)
- `templates/buku-besar-template.md` — Buku besar (ledger) template for tracking operational expenses, income, and GAP analysis